import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)
import home from '../views/Home.vue'
import showWay from '../views/showWay.vue'

// import certiMessage1 from '../views/message/certiMessage1.vue'
// 嵌套路由开始
import personInformat from '../views/personInformat/personInformat.vue'
// import performInformat from '../views/performInformat/performInformat.vue'
// import workExperience from '../views/workExperience/workExperience.vue'
// import trainExperience from '../views/trainExperience/trainExperience.vue'
// import testReview from '../views/testReview/testReview.vue'
// import talentInventory from '../views/talentInventory/talentInventory.vue'
// import educatExperience from '../views/educatExperience/educatExperience.vue'
// import languageInformat from '../views/languageInformat/languageInformat.vue'
// import qualificat from '../views/qualificat/qualificat.vue'
import testFile from '../views/testFile/testFile.vue'
import mainView from '../views/mainView/mainView.vue'
import specOffer from '../views/specOffer/specOffer.vue'
import viewTeam from '../views/viewTeam/viewTeam.vue'
import searchResult from '../views/searchResult/searchResult.vue'
import assistantLearn from '../views/assistantLearn/assistantLearn.vue'
import viewSubteam from '../views/viewSubteam/viewSubteam.vue'


const routes = [
  {
    path: '/',
    // name: 'home',
    component: showWay,
  },
  {
    path: '/home',
    // name: 'home',
    component: home,
    // 嵌套路由
    children: [
      {
        // 个人信息
        path: '',
        component: personInformat
      },
      // {
      //   // 绩效信息
      //   path: 'performInformat',
      //   component: performInformat
      // },
      // {
      //   // 工作经历
      //   path: 'workExperience',
      //   component: workExperience
      // },
      // {
      //   // 培训经历
      //   path: 'trainExperience',
      //   component: trainExperience
      // },
      // {
      //   // 测试及评审
      //   path: 'testReview',
      //   component: testReview
      // },
      // {
      //   // 人才盘点
      //   path: 'talentInventory',
      //   component: talentInventory
      // },
      // {
      //   // 教育经历
      //   path: 'educatExperience',
      //   component: educatExperience
      // },
      // {
      //   // 语言信息
      //   path: 'languageInformat',
      //   component: languageInformat
      // },
      // {
      //   // 任职资格
      //   path: 'qualificat',
      //   component: qualificat
      // },
     
    ]
  },
  {
    // 主查看页面
    path: '/mainView',
    component: mainView
  },
  {
    // offer页面
    path: '/specOffer',
    component: specOffer
  },
  {
    // 查看团队页面
    path: '/viewTeam',
    component: viewTeam
  },
  {
    // 搜索结果页面
    path: '/searchResult',
    component: searchResult
  },
  {
    // CEO助理学习页面
    path: '/assistantLearn',
    component: assistantLearn
  },
  {
    // 查看子团队页面
    path: '/viewSubteam',
    component: viewSubteam
  },
  {
    // 自己练习页面
    path: '/testFile',
    component: testFile
  }

]

const router = new VueRouter({
  routes
})

export default router
