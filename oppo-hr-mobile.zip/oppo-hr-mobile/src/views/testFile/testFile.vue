<template>
  <!-- 这是练习页面 -->
  <div>
    
  </div>
</template>

<script>
export default {
  data() {},

  methods: {}
};
</script>

<style>
</style>