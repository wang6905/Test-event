<template>
  <!-- 这是工作经历  workExperience    的子界面 -->
  <div class="woExp">
    <p class="one">工作经历</p>
    <div class="timeAxi">
      <!-- oppo工作经历 时间轴-->
      <div class="inside">
        <p class="exper">oppo工作经历</p>
        <div class="inOne">
          <el-timeline class="insideExper">
            <el-timeline-item
              timestamp="2018/4/12"
              placement="top"
              v-for="(item,index) in insideList "
              :key="index"
            >
              <el-card>
                <h4>{{item.name}}</h4>
                <p>{{item.eve}}</p>
              </el-card>
            </el-timeline-item>
          </el-timeline>
        </div>
      </div>
      <!-- 非oppo工作经历 -->
      <div class="external"></div>
    </div>
  </div>
  <!-- 时间轴 -->
 
</template>

<script>
export default {
  name: "workExperience",
  data() {
    return {
     
      //
      insideList: [
        {
          name: "小虎",
          eve: "提交数据"
        },
        {
          name: "小虎",
          eve: "提交数据"
        }
      ]
    };
  },
 
};
</script>

<style lang="less" scoped>
.woExp {
  width: 351px;
  margin: 9px auto 0;
  box-sizing: border-box;
  .one {
    line-height: 15px;
    text-align: left;
    margin-bottom: 10px;
    border-left: 5px solid #19cbab;
    padding-left: 9.5px;
    font-size: 14.5px;
  }
  .timeAxi {
    .inside {
      .exper {
        width: 104px;
        line-height: 20px;
        background-color: #19cbab;
        text-align: center;
        color: #fff;
        font-size: 12px;
        border-radius: 10px;
        margin-top: 13.5px;
        margin-bottom: 9.5px;
        margin-left: 25px;
      }
      .inOne {
        text-align: left;
        margin-left: 13.5px;
        .insideExper {
          .el-timeline-item {
            /deep/ .el-timeline-item__tail {
              //修改时间纵轴线
              border-left: 2.5px solid #b2b2b2;
              margin-left: -3px;
            }
            /deep/ .el-timeline-item__node {
              //修改时间线圆点尺寸
              width: 6px;
              height: 6px;
              background-color: #b2b2b2;
            }
            /deep/ .el-timeline-item__wrapper {
              padding-left: 11px;
              /deep/ .el-timeline-item__content {
                // padding-top: 10px;
                // padding-left: 11.5px;
                // padding-bottom: 12.5px;
                border-top: 5px solid #19cbab;
                box-sizing: border-box;
                width: 100%;
                height: 65px;
                /deep/ .el-card {
                  /deep/ .el-card__body {
                    padding-top: 10px;
                    padding-left: 11.5px;
                    padding-bottom: 12.5px;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>