<template>
  <div>
    <el-row>
      <el-button type="warning" @click="toHome" icon="el-icon-star-off" circle style="width:120px;height:120px;margin:80px auto"></el-button>
    </el-row>
  </div>
</template>

<script>
export default {
  name: "showWay",
  data() {
    return {};
  },
  methods: {
    toHome(){
      this.$router.push('home')
    }
  }
};
</script>

<style lang="less" scoped>
</style>
