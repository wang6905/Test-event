<template>
  <!-- 这是查看子团队页面 viewSubteam -->
  <div class="viewSuPage">
      
  </div>
</template>

<script>
export default {
  name: "viewSubteam"
};
</script>

<style>
</style>