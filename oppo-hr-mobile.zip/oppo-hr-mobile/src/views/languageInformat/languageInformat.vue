<template>
  <!--这是 语言信息  子路由界面 languageInformat -->
  <div class="lanInfor">
    <p class="one">语言信息</p>
    <div class="form">
      <div class="top"></div>
      <div class="main">
        <div class="lanMess" v-for="(item,index) in lanMessList">
          <span class="lanMessLeft">{{item.name}}</span>
          <span class="lanMessRight">{{item.degree}}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "performInformat",
  data() {
    return {
      lanMessList: [
        {
          name: "英语",
          degree: "CET"
        },
         {
          name: "英语",
          degree: "CET"
        }
      ]
    };
  },
  methods: {
    //   使表格高亮的方法
    tableHeaderColor({ row, rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #f3fcfb;color:#50d7be;font-weight: 600;";
      }
    }
  }
};
</script>

<style lang="less" scoped>
//
//
.lanInfor {
  width: 351px;
  margin: 9px auto 0;
  box-sizing: border-box;
  .one {
    line-height: 15px;
    text-align: left;
    margin-bottom: 10px;
    border-left: 5px solid #19cbab;
    border-radius: 1px;
    padding-left: 9.5px;
    font-size: 15px;
    font-family: PingFang SC;
    font-weight: 500;
  }
  .form {
    .top {
      height: 5px;
      width: 351px;
      margin: 9px auto 0;
      box-sizing: border-box;
      background-color: #19cbab;
      border-radius: 2px 2px 0 0;
    }
    .main {
      width: 351px;
      margin: 0 auto 0;
      .lanMess {
        border-bottom: 1px solid #e8faf6;

        box-sizing: border-box;
        height: 35px;
        background-color: #ffffff;
        text-align: left;
        font-size: 12px;
        line-height: 35px;
        .lanMessLeft {
          display: inline-block;
          width: 55px;
          height: 35px;
          text-align: center;
          background-color: #f3fcfb;
          color: #19cbab;
          font-family: PingFang SC;
          font-weight: 500;
        }
        .lanMessRight {
          margin-left: 25px;
          color: #343434;
          font-weight: 500;
        }
      }
    }
  }
}
</style>