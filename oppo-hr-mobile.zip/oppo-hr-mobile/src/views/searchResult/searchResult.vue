<template>
  <!-- 这是搜索结果页面 searchResult -->
  <div class="searPage">
      
  </div>
</template>

<script>
export default {
  name: "searchResult"
};
</script>

<style>
</style>