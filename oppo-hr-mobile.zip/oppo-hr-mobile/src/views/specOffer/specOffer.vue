<template>
  <!-- 这是offer页面 specOffer -->
  <div class="spPage">
      
  </div>
</template>

<script>
export default {
  name: "specOffer"
};
</script>

<style>
</style>