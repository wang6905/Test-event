<template>
  <!-- 这是主查看页面 mainView -->
  <div class="maPage">
      
  </div>
</template>

<script>
export default {
  name: "mainView"
};
</script>

<style>
</style>