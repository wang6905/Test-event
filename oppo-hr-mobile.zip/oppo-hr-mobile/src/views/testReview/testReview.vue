<template>
  <!-- 这是  testReview  测试及评审子页面 -->
  <div class="testReview">
    <div class="tesTitle">测试及评审</div>
    <div class="tesContent">
      <p class="tesTop"></p>
      <div class="tesFold">
        <!-- 折叠面板 -->
        <el-collapse accordion>
          <el-collapse-item>
            <!--  -->
            <template slot="title">
              <span>M1干部评测</span>
              <span>111111111</span>
            </template>
            <!-- 第一个 -->
            <div class="tesFoldMess">
              <div class="tesFoldLeft">
                <span class="tesFoldLeftOne">待任命部门:</span>
                <span class="tesFoldLeftTwo"></span>
              </div>
              <div class="tesFoldRight">
                <span class="tesFoldRightOne">待任命部门:</span>
                <span class="tesFoldRightTwo"></span>
              </div>
            </div>
            <!-- 认识能力和领导力素质 -->
            <div class="tesFoldBase clearfix">
              <p class="tesFdEng">
                英语测评:
                <span></span>
              </p>
              <span class="tesFdCon">认知能力测试</span>
              <div class="tesFdContent">
                <p class="tesFdContentO">
                  言语推理:
                  <span>1</span>
                </p>
                <p class="tesFdContentT">
                  数字推理:
                  <span>1</span>
                </p>
                <p class="tesFdContentH">
                  抽象推理:
                  <span>1</span>
                </p>
              </div>
              <div class="tesLead">领导力素质</div>
              <div class="tesFdContent">
                <p class="tesFdContentO">
                  战略远见:
                  <span>1</span>
                </p>
                <p class="tesFdContentT">
                  商业智慧:
                  <span>1</span>
                </p>
                <p class="tesFdContentH">
                  变革影响:
                  <span>1</span>
                </p>
              </div>
              <div class="tesFdContent">
                <p class="tesFdContentO" style="width:91.5px;margin-right:29px">
                  企业家精神:
                  <span>1</span>
                </p>
                <p class="tesFdContentT">
                  决断力:
                  <span>1</span>
                </p>
                <p class="tesFdContentH">
                  负责到底:
                  <span>1</span>
                </p>
              </div>
              <div class="tesFdContent" style="margin-bottom: 14.5px;">
                <p class="tesFdContentO" style="width:115.5px;margin-right:101.5px">
                  为客户创造价值:
                  <span>1</span>
                </p>
                <p class="tesFdContentH" style="width:103.5px">
                  打造高效团队:
                  <span>1</span>
                </p>
              </div>
              <!--  -->
            </div>
            <!-- 优势 -->
            <div class="tesAdvage clearfix" style="margin-bottom:5px">
              <p class="tesAdvageOne">优势</p>
              <div class="tesAdvageTwo"></div>
            </div>
            <!-- 进一步提升的领域 -->
            <div class="tesPromot clearfix" style="margin-bottom:5px">
              <p class="tesAdvageOne">进一步提升的领域</p>
              <div class="tesAdvageTwo"></div>
            </div>
            <!-- 测评报告 -->
            <div class="tesEvaluat clearfix">
              <p class="tesAdvageOne" style="margin-bottom:15.5px;">测评</p>
              <div class="tesEvaluatEn clearfix">
                <div class="tesEvaluatEnOne">
                  <img class="enOne" src="../../assets/svg (1)/svg图标/附件.svg" alt />
                  <span>附件</span>
                  <img class="enTwo" src="../../assets/svg (1)/svg图标/查看.svg" alt />
                </div>
                <div class="tesEvaluatEnTwo">
                  <img class="enOne" src="../../assets/svg (1)/svg图标/附件.svg" alt />
                  <span>附件</span>
                  <img class="enTwo" src="../../assets/svg (1)/svg图标/查看.svg" alt />
                </div>
                <div class="tesEvaluatEnThr">
                  <img class="enOne" src="../../assets/svg (1)/svg图标/附件.svg" alt />
                  <span>附件</span>
                  <img class="enTwo" src="../../assets/svg (1)/svg图标/查看.svg" alt />
                </div>
                <div class="tesEvaluatEnFou">
                  <img class="enOne" src="../../assets/svg (1)/svg图标/附件.svg" alt />
                  <span>附件</span>
                  <img class="enTwo" src="../../assets/svg (1)/svg图标/查看.svg" alt />
                </div>
              </div>
            </div>
            <!-- 评审 -->
            <div class="tesReview">
              <div class="tesReviewOne">评审</div>
              <div class="tesReviewPers">评审参与人</div>
              <div class="tesReviewTime">2016</div>
            </div>
            <div class="tesReviewResu">
              <div class="tesReviewLeft">
                <span class="tesReviewLeftOne">评审结果:</span>
                <span class="tesReviewLeftTwo">同意任命</span>
              </div>
              <div class="tesReviewRight">
                <img src="../../assets/svg (1)/png/不同意.png" alt  style="margin-right:4.5px"/>
                <img src="../../assets/svg (1)/png/同意.png" alt />
              </div>
            </div>
            <div class="tesFeedBack clearfix">
              <div class="tesFeedBackOne">现场反馈</div>
              <div class="tesFeedBackCom">Tony</div>
            </div>
          </el-collapse-item>
        </el-collapse>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "testReview",
  data() {
    return {};
  },
  methods: {}
};
</script>

<style  lang="less" scoped>
.testReview {
  padding-top: 9px;
  padding-left: 12px;
  box-sizing: border-box;
  .tesTitle {
    border-left: 5px solid #19cbab;
    box-sizing: border-box;
    padding-left: 9.5px;
    font-size: 15px;
    color: #343434;
    font-family: PingFang SC;
    font-weight: 500;
    line-height: 15px;
    text-align: left;
    margin-bottom: 11.5px;
  }
  .tesContent {
    width: 351px;
    .tesTop {
      height: 5px;
      background-color: #19cbab;
      border-radius: 2px 2px 0 0;
    }
    .tesFold {
      // 折叠面板
      .el-collapse {
        .el-collapse-item {
          /deep/ .el-collapse-item__header {
            border-radius: 0 0 2px 2px;
            border: 0;
            height: 35px;
          }
          //   第一个
          /deep/ .el-collapse-item__wrap {
            margin-top: 5px;
            border-radius: 2px;
            .el-collapse-item__content {
              padding: 0;
              .tesFoldMess {
                //
                background-color: white;
                height: 35px;
                .tesFoldLeft {
                  box-sizing: border-box;
                  width: 175.5px;
                  height: 35px;
                  background-color: skyblue;
                  border-right: 1px solid #f6fdfc;
                  float: left;
                  font-size: 12px;
                  color: #b2b2b2;
                  font-family: Microsoft YaHei;
                  .tesFoldLeftOne {
                    margin-left: 14px;
                  }
                }
                .tesFoldRight {
                  font-size: 12px;
                  color: #b2b2b2;
                  font-family: Microsoft YaHei;
                  float: left;
                  box-sizing: border-box;
                  width: 175px;
                  height: 35px;
                  background-color: pink;
                  .tesFoldRightOne {
                    margin-left: 12.5px;
                  }
                }
              }
              .tesFoldBase {
                margin-bottom: 5px;
                border-radius: 2px;
                font-family: Microsoft YaHei;
                background-color: white;
                width: 351px;
                height: 198.5px;
                margin-top: 5px;
                .tesFdEng {
                  line-height: 12px;
                  width: 79px;
                  height: 12.5px;
                  font-size: 12px;
                  color: rgba(178, 178, 178, 1);
                  margin-top: 13px;
                  margin-left: 14px;
                  margin-bottom: 17.5px;
                  span {
                    color: #19cbab;
                  }
                }
                .tesFdCon {
                  font-size: 12px;
                  margin-bottom: 12px;
                  margin-left: 14px;
                  color: rgba(52, 52, 52, 1);
                }
                .tesFdContent {
                  margin-bottom: 12.5px;
                  line-height: 12px;
                  margin-left: 14px;
                  height: 12px;
                  p {
                    width: 79px;
                    float: left;
                    color: rgba(178, 178, 178, 1);
                    font-size: 12px;
                    margin-right: 42px;
                    span {
                      font-size: 12px;
                      color: #19cbab;
                    }
                  }
                  .tesFdContentH {
                    margin-right: 0;
                  }
                }
                .tesLead {
                  line-height: 12px;
                  margin-left: 14px;
                  font-size: 12px;
                  font-weight: 400;
                  color: rgba(52, 52, 52, 1);
                  margin-bottom: 12.5px;
                }
              }
              .tesAdvage,
              .tesPromot,
              .tesEvaluat {
                border-radius: 2px;
                width: 351px;
                height: 105px;
                background-color: skyblue;
                .tesAdvageOne {
                  margin-bottom: 12px;
                  font-size: 12px;
                  font-family: PingFang SC;
                  font-weight: 500;
                  color: rgba(51, 51, 51, 1);
                  line-height: 12px;
                  margin-top: 9px;
                  margin-left: 15px;
                }
                .tesAdvageTwo {
                  line-height: 7px;
                  width: 331.5px;
                  height: 48.5px;
                  margin-left: 14.5px;
                  background-color: pink;
                }
              }
              .tesEvaluat {
                .tesEvaluatEn {
                  background-color: pink;
                  .tesEvaluatEnOne,
                  .tesEvaluatEnTwo,
                  .tesEvaluatEnThr,
                  .tesEvaluatEnFou {
                    width: 93.5px;
                    padding-left: 9.5px;
                    box-sizing: border-box;
                    background-color: #e8faf6;
                    float: left;
                    //
                    border-radius: 2px;
                    line-height: 21px;
                    height: 23px;
                    text-align: left;
                    font-size: 9px;
                    .enOne {
                      vertical-align: middle;
                      width: 13px;
                      height: 15px;
                      margin-right: 8px;
                    }
                    .enTwo {
                      width: 10px;
                      margin-left: 20.5px;
                    }
                  }
                  .tesEvaluatEnOne {
                    margin-left: 42.5px;
                    margin-bottom: 9px;
                  }
                  .tesEvaluatEnTwo {
                    margin-left: 67px;
                    margin-bottom: 9px;
                  }
                  .tesEvaluatEnThr {
                    margin-left: 42.5px;
                  }
                  .tesEvaluatEnFou {
                    margin-left: 67px;
                  }
                }
              }
              .tesReview {
                height: 20px;
                margin-top: 15px;
                background-color: pink;
                width: 351px;
                .tesReviewOne {
                  width: 47.5px;
                  height: 20px;
                  background-color: #19cbab;
                  font-size: 12px;
                  font-weight: 400;
                  line-height: 20px;
                  text-align: center;
                  color: white;
                  border-radius: 10px;
                  float: left;
                }
                .tesReviewPers {
                  color: #b2b2b2;
                  float: left;
                  line-height: 20px;
                  margin-left: 10px;
                }
                .tesReviewTime {
                  color: #b2b2b2;
                  float: right;
                  line-height: 20px;
                }
              }
              .tesReviewResu {
                margin-top: 7px;
                width: 351px;
                height: 50px;
                line-height: 50px;
                background-color: pink;
                .tesReviewLeft {
                  float: left;
                  font-size: 12px;
                  .tesReviewLeftOne {
                    color: #b2b2b2;
                    margin-left: 14px;
                  }
                  .tesReviewLeftTwo {
                    margin-left: 6.5px;
                    color: #343434;
                  }
                }
                .tesReviewRight {
                  float: right;
                  margin-right: 20px;
                }
              }
              .tesFeedBack {
                width: 351px;
                height: 120px;
                background-color: pink;
                margin-top: 5px;
                border-radius: 2px;
                .tesFeedBackOne {
                  margin-left: 15px;
                  font-size: 12px;
                  font-family: PingFang SC;
                  font-weight: 500;
                  color: rgba(51, 51, 51, 1);
                  line-height: 36px;
                  line-height: 12px;
                  margin-top: 9px;
                }
                .tesFeedBackCom {
                  margin-left: 15.5px;
                  width: 319px;
                  height: 66px;
                  margin-top: 12px;
                }
              }
              background-color: #eeeeee;
              text-align: left;
              width: 351px;
              //   height: 35px;
              box-sizing: border-box;
              line-height: 36px;
            }
          }
          //
        }
      }
      // 折叠面板
    }
  }
}
</style>