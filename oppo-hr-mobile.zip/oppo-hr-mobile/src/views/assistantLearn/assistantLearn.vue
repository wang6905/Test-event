<template>
  <!-- 这是CEO助理学习页面 assistantLearn -->
  <div class="assisPage">
      
  </div>
</template>

<script>
export default {
  name: "assistantLearn"
};
</script>

<style>
</style>