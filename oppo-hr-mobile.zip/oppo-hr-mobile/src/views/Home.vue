<template>
  <div class="home">
    <!-- 导航栏nav -->
    <div class="headerNav">
      <div class="headerLeft">
        <img src="../assets/svg (1)/svg图标/名片.svg" alt />
        <span>人力资源部总经理</span>
      </div>
      <div class="headerRight">
        <img src="../assets/temp/1.jpg" alt />
        <span>张心云</span>
      </div>
    </div>
    <div>
      <router-view></router-view>
    </div>
    <div>
      <performInformat></performInformat>
      <qualificat></qualificat>
      <workExperience></workExperience>
      <educatExperience></educatExperience>
      <languageInformat></languageInformat>
      <testReview></testReview>
      <talentInventory></talentInventory>
      <trainExperience></trainExperience>
    </div>

    <!--  -->
  </div>
</template>

<script>
export default {
  name: "headerNav"
};
</script>

<style lang="less" scoped>
.headerNav {
  background-color: #ffffff;
  line-height: 35px;
  color: black;
  display: flex;
  justify-content: space-between;
  .headerLeft {
    font-size: 11.5px;
    color: #c3c3c3;
    img {
      vertical-align: middle;
      margin-right: 7px;
      margin-left: 12.5px;
      height: 15px;
    }
    span {
      vertical-align: middle;
    }
  }
  .headerRight {
    color: #4e4e4e;
    margin-right: 11px;
    font-size: 12px;
    img {
      margin-right: 9.5px;
      width: 20px;
    }
  }
}
</style>