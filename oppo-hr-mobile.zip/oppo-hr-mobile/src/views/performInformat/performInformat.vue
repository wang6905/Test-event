<template>
  <!--绩效信息  子路由界面 performInformat -->
  <div class="perInf">
    <p class="one">绩效信息</p>
    <div class="form">
      <div class="top"></div>
      <div class="main">
        <a-table
          :columns="columns"
          :dataSource="data"
          bordered
          slot="name"
          :pagination="pagination"
        >
          <template slot="name" slot-scope="text">
            <a href="javascript:;">{{text}}</a>
          </template>
        </a-table>
      </div>
    </div>
  </div>
</template>

<script>
const columns = [
  {
    width: "100px",
    align: "center",
    title: "年份",
    dataIndex: "name",
    scopedSlots: { customRender: "name" }
  },
  {
    align: "center",
    title: "类型",
    className: "column-money",
    dataIndex: "money"
  },
  {
    align: "center",
    title: "结果",
    dataIndex: "address"
  },
  {
    align: "center",
    title: "类型",
    dataIndex: "money1"
  },
  {
    align: "center",
    title: "结果",
    dataIndex: "address1"
  }
];
const data = [
  // 这是代表表格的行数
  {
    key: "1",
    name: "2019",
    money: "年度",
    address: "A",
    money1: "半年度",
    address1: "A"
  },
  {
    key: "2",
    name: "2019",
    money: "年度",
    address: "A",
    money1: "半年度",
    address1: "A"
  },
  {
    key: "3",
    name: "2019",
    money: "年度",
    address: "A",
    money1: "半年度",
    address1: "A"
  }
];
export default {
  name: "performInformat",
  data() {
    return {
      pagination: false,
      data,
      columns
    };
  },
  methods: {}
};
</script>

<style lang="less" scoped>
//ant 表格样式
/deep/ .ant-table-row {
  height: 36px;
  background-color: #ffffff;
  td {
    padding: 0;
  }
}
/deep/ .ant-table-thead {
  //修改表头字体
  .ant-table-align-center {
    color: #19cbab;
    font-family: Microsoft YaHei;
    font-weight: 400;
  }
}
/deep/ .ant-table-align-center {
  padding: 0;
  height: 35px;
  background-color: #f3fcfb;
  border: none;
}
th.column-money,
td.column-money {
  text-align: center !important;
}
//  ant 表格样式
.perInf {
  width: 351px;
  margin: 9px auto 0;
  box-sizing: border-box;
  .one {
    line-height: 15px;
    text-align: left;
    margin-bottom: 10px;
    border-left: 5px solid #19cbab;
    padding-left: 9.5px;
    font-size: 14.5px;
  }
  .form {
    .top {
      height: 5px;
      width: 351px;
      margin: 9px auto 0;
      box-sizing: border-box;
      background-color: #19cbab;
      border-radius: 2px 2px 0 0;
    }
    .main {
      width: 351px;
      margin: 0 auto 0;
    }
  }
}
</style>