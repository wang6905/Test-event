<template>
<!-- 个人信息界面  personInformat -->
  <div class="home">
    <div class="main">
      <div class="top"></div>
      <div class="message">
        <div class="mainLeft">
          <img src="../../assets/temp/1.jpg" alt />
        </div>
        <span class="new">100108888</span>
        <div class="mainRight">
          <p class="one">
            <span>张心云 FionaZhang</span>
          </p>
          <p class="two">
            <span style=" font-size: 9px;">zhangxinyun</span>
          </p>
          <p class="fou">
            <img src="../../assets/svg (1)/svg图标/电话.svg" alt />
            <span class="thr">15572938233</span>
          </p>
          <p class="five">
            <img src="../../assets/svg (1)/svg图标/邮箱.svg" alt />
            <span class="thr">zhangxinyun@ht.com</span>
          </p>
          <p class="six">
            <img src="../../assets/svg (1)/svg图标/上司.svg" alt />
            <span class="thr">直接上级 李云 10080222</span>
          </p>
          <p class="sev">
            <img src="../../assets/svg (1)/svg图标/地点.svg" alt />
            <span class="thr">当前工作地 深圳</span>
          </p>
        </div>
      </div>
      <!-- 下面 -->
    </div>
    <div class="main2 clearfix">
      <div class="main2Message">
        <div class="one"></div>
        <div class="two"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
    name:'personInformat'
};
</script>

<style lang="less" scoped>
.main {
  position: relative;
  width: 351px;
  height: 155.5px;
  background-color: skyblue;
  margin: 9.5px auto 0;
  // height: 220px;

  .top {
    height: 5px;
    border-radius: 2px 2px 0 0;
    background-color: #19cbab;
  }
  .message {
    .mainLeft {
      margin-top: 14.5px;
      margin-left: 15px;
      padding-top: 3.5px;
      float: left;
      width: 75px;
      height: 121px;
      img {
        width: 73px;
        height: 96.5px;
      }
    }
    .new {
      position: absolute;
      left: 17px;
      top: 126.5px;
      border-radius: 7px;
      font-size: 7.5px;
      width: 70.5px;
      line-height: 14px;
      text-align: center;
      background-color: #eeeeee;
    }
    .mainRight {
      margin-left: 35.5px;
      width: 175px;
      float: left;
      margin-top: 15.5px;
      .one {
        height: 17px;
        font-size: 15px;
        font-family: "Microsoft YaHei";
        font-weight: 400;
        color: rgba(52, 52, 52, 1);
        line-height: 18px;
        text-align: left;
        span {
          font-family: Microsoft YaHei;
          width: 147px;
          display: inline-block;
        }
      }
      .two {
        margin-top: -3px;
        line-height: 10px;
        width: 57px;
        span {
          // display: inline-block;
          // width: 57px;
          // height: 10px;
          color: #b2b2b2;
        }
      }
      .fou {
        margin-top: 6.5px;
        text-align: left;
        line-height: 15px;
        width: 163px;
        img {
          border: 1px dashed #8f8f8f;
          box-sizing: border-box;
          vertical-align: middle;
          width: 15px;
          height: 15px;
        }
        span {
          vertical-align: middle;
          font-size: 12px;
        }
      }
      .five {
        margin-top: 6.5px;
        text-align: left;
        line-height: 15px;
        width: 163px;
        img {
          border: 1px dashed #8f8f8f;
          box-sizing: border-box;
          vertical-align: middle;
          width: 15px;
          height: 15px;
        }
        span {
          vertical-align: middle;
          font-size: 12px;
        }
      }
      .six {
        margin-top: 6.5px;
        text-align: left;
        line-height: 15px;
        width: 163px;
        img {
          border: 1px dashed #8f8f8f;
          box-sizing: border-box;
          vertical-align: middle;
          width: 15px;
          height: 15px;
        }
        span {
          vertical-align: middle;
          font-size: 12px;
        }
      }
      .sev {
        margin-top: 6.5px;
        text-align: left;
        line-height: 15px;
        width: 163px;
        img {
          border: 1px dashed #8f8f8f;
          box-sizing: border-box;
          vertical-align: middle;
          width: 15px;
          height: 15px;
        }
        span {
          vertical-align: middle;
          font-size: 12px;
        }
      }
    }
  }
}

.main2 {
  margin-left: 12px;
  width: 351px;
  height: 64.5px;
  background-color: #fdfdfd;
  .main2Message {
    margin-top: 13px;
    margin-left: 14.5px;
    width: 309px;
    height: 36px;
    background-color: skyblue;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    .one {
      height: 12px;
      background-color: pink;
    }
    .two {
      height: 12px;
      background-color: pink;
    }
  }
}
</style>