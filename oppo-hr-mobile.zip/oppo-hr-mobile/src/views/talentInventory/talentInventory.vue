<template>
  <!-- 这是人才盘点  talentInventory    的子界面 -->
  <div class="talIntory">
    <p class="one">人才盘点</p>
    <!--  -->
    <div class="timeAxi">
      <div class="inside">
        <p class="inTalIntory">2019年人才盘点</p>
      </div>
    </div>
    <!-- 折叠面板 -->
    <div class="talIntoryFold">
      <el-collapse accordion>
        <el-collapse-item>
          <!--  -->
          <template slot="title">
            <span>人才盘点</span>
            <span>人才盘点</span>
          </template>
          <!-- 第一个 -->
          <div class="tesFoldMess">
            <div class="tesFoldLeft">
              <span class="tesFoldLeftOne">待任命部门:</span>
              <span class="tesFoldLeftTwo"></span>
            </div>
            <div class="tesFoldRight">
              <span class="tesFoldRightOne">待任命部门:</span>
              <span class="tesFoldRightTwo"></span>
            </div>
          </div>
          <!-- 认识能力和领导力素质 -->
          <div class="tesFoldBase clearfix">
            <p class="tesFoldBaseOne">优势项:</p>
            <div class="talAdvatg" :style="{whiteSpace:isok?'nowrap':null}" @click="change">
              认识能力和领导力素质认识能力和领导力素质认识能力和领导力素质
              <img src="../../assets/svg (1)/png/下拉.png" alt />
            </div>
            <p class="tesFoldBaseOne">待发展项:</p>
            <div class="talAdvatg" :style="{whiteSpace:isokOne?'nowrap':null}" @click="changeOne">
              认识能力和领导力素质认识能力和领导力素质认识能力和领导力素质
              <img src="../../assets/svg (1)/png/下拉.png" alt />
            </div>
            <p class="tesFoldBaseOne">建议方向:</p>
            <div class="talAdvatg" :style="{whiteSpace:isokTwo?'nowrap':null}" @click="changeTwo">
              认识能力和领导力素质认识能力和领导力素质认识能力和领导力素质
              <img src="../../assets/svg (1)/png/下拉.png" alt />
            </div>
            <p class="tesFoldBaseOne">建议培养模式:</p>
            <div class="talAdvatg" :style="{whiteSpace:isokThr?'nowrap':null}" @click="changeThr">
              认识能力和领导力素质认识能力和领导力素质认识能力和领导力素质
              <img src="../../assets/svg (1)/png/下拉.png" alt />
            </div>
            <p class="tesFoldBaseOne">备注:</p>
            <div class="talAdvatg" :style="{whiteSpace:isokFou?'nowrap':null}" @click="changeFou">
              认识能力和领导力素质认识能力和领导力素质认识能力和领导力素质
              <img src="../../assets/svg (1)/png/下拉.png" alt />
            </div>
          </div>
        </el-collapse-item>
      </el-collapse>
    </div>
  </div>
</template>

<script>
export default {
  name: "workExperience",
  data() {
    return {
      isok: true,
      isokOne: true,
      isokTwo: true,
      isokThr: true,
      isokFou: true
    };
  },
  methods: {
    change() {
      this.isok = !this.isok;
    },
    changeOne() {
      this.isokOne = !this.isokOne;
    },
    changeTwo() {
      this.isokTwo = !this.isokTwo;
    },
    changeThr() {
      this.isokThr = !this.isokThr;
    },
    changeFou() {
      this.isokFou = !this.isokFou;
    }
  }
};
</script>

<style lang="less" scoped>
.talIntory {
  width: 351px;
  margin: 9px auto 0;
  box-sizing: border-box;
  .one {
    line-height: 15px;
    text-align: left;
    margin-bottom: 10px;
    border-left: 5px solid #19cbab;
    padding-left: 9.5px;
    font-size: 14.5px;
  }
  .timeAxi {
    //   人才盘点
    .inside {
      .inTalIntory {
        font-family: PingFang SC;
        width: 116px;
        line-height: 20px;
        background-color: #19cbab;
        text-align: center;
        color: #fff;
        font-size: 15px;
        border-radius: 10px;
        margin-top: 13.5px;
        margin-bottom: 12.5px;
        margin-left: -0.5px;
      }
      //   -----------
    }
  }
  //   折叠面板
  .talIntoryFold {
    // 折叠面板
    .el-collapse {
      .el-collapse-item {
        /deep/ .el-collapse-item__header {
          border-radius: 0 0 2px 2px;
          border: 0;
          height: 35px;
        }
        //   第一个
        /deep/ .el-collapse-item__wrap {
          margin-top: 5px;
          border-radius: 2px;
          .el-collapse-item__content {
            padding: 0;
            .tesFoldMess {
              //
              background-color: white;
              height: 35px;
              .tesFoldLeft {
                box-sizing: border-box;
                width: 175.5px;
                height: 35px;
                background-color: skyblue;
                border-right: 1px solid #f6fdfc;
                float: left;
                font-size: 12px;
                color: #b2b2b2;
                font-family: Microsoft YaHei;
                .tesFoldLeftOne {
                  margin-left: 14px;
                }
              }
              .tesFoldRight {
                font-size: 12px;
                color: #b2b2b2;
                font-family: Microsoft YaHei;
                float: left;
                box-sizing: border-box;
                width: 175px;
                height: 35px;
                background-color: pink;
                .tesFoldRightOne {
                  margin-left: 12.5px;
                }
              }
            }
            background-color: #eeeeee;
            text-align: left;
            width: 351px;
            //   height: 35px;
            box-sizing: border-box;
            line-height: 36px;
            .tesFoldBase {
              margin-bottom: 5px;
              border-radius: 2px;
              font-family: Microsoft YaHei;
              background-color: white;
              width: 351px;
              //   height: 198.5px;
              margin-top: 5px;
              .tesFoldBaseOne {
                margin-left: 14.5px;
                height: 15px;
                line-height: 15px;
                margin-top: 18px;
              }
              .talAdvatg {
                overflow: hidden;
                text-overflow: ellipsis;
                padding-right: 29px;
                box-sizing: border-box;
                width: 321px;
                height: 79.5px;
                background-color: pink;
                border-radius: 2px;
                border: 1px solid #eeeeee;
                margin-left: 15px;
                margin-top: 8px;
                position: relative;
                line-height: 26.5px;
                img {
                  width: 9px;
                  height: 11px;
                  position: absolute;
                  right: 10px;
                  top: 7px;
                }
              }
            }
          }
        }
        //
      }
    }
    // 折叠面板
  }
}
</style>