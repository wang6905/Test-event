<template>
  <!-- 这是教育经历  educatExperience    的子界面 -->
  <div class="trExper">
    <p class="one">教育经历</p>
    <div class="timeAxi">
      <!-- 教育经历 时间轴-->
      <div class="inside">
        <div class="inOne">
          <el-timeline class="insideExper">
            <el-timeline-item
              timestamp="2018/4/12"
              placement="top"
              v-for="(item,index) in insideList "
              :key="index"
            >
              <el-card>
                <div class="edSchool">
                  <img src="../../assets/svg (1)/png/学校.png" alt />
                  <p>{{item.name}}</p>
                </div>
                <div class="edDegree">
                  <img src="../../assets/svg (1)/png/学位.png" alt />
                  <p>{{item.eve}}</p>
                </div>
                <div class="edResour">
                  <img src="../../assets/svg (1)/png/资源管理.png" alt />
                  <p>{{item.eveOne}}</p>
                </div>
                <div class="edSystem">
                  <img src="../../assets/svg (1)/png/学制.png" alt />
                  <p>{{item.eveTwo}}</p>
                </div>
              </el-card>
            </el-timeline-item>
          </el-timeline>
        </div>
      </div>
      <!-- 项目培训 -->
    </div>
  </div>
</template>

<script>
export default {
  name: "workExperience",
  data() {
    return {
      insideList: [
        {
          name: "北京大学",
          eve: "博士研究生",
          eveOne: "人力资源管理",
          eveTwo: "全日制"
        },
         {
          name: "北京大学",
          eve: "博士研究生",
          eveOne: "人力资源管理",
          eveTwo: "全日制"
        },
         {
          name: "北京大学",
          eve: "博士研究生",
          eveOne: "人力资源管理",
          eveTwo: "全日制"
        },
      ]
    };
  }
};
</script>

<style lang="less" scoped>
.trExper {
  width: 351px;
  margin: 9px auto 0;
  box-sizing: border-box;
  .one {
    line-height: 15px;
    text-align: left;
    margin-bottom: 10px;
    font-family: PingFang SC;
    font-weight: 500;
    border-left: 5px solid #19cbab;
    padding-left: 9.5px;
    font-size: 15px;
  }
  .timeAxi {
    //   通用培训
    .inside {
      .inOne {
        text-align: left;
        margin-left: 13.5px;
        .insideExper {
          .el-timeline-item {
            // height: 148.5px;
            height: 107px;
            padding-bottom: 0;
            /deep/ .el-timeline-item__tail {
              //修改时间纵轴线
              border-left: 2.5px solid #b2b2b2;
              margin-left: -3px;
            }
            /deep/ .el-timeline-item__node {
              //修改时间线圆点尺寸
              width: 6px;
              height: 6px;
              background-color: #b2b2b2;
            }
            /deep/ .el-timeline-item__wrapper {
              padding-left: 11px;
              /deep/ .el-timeline-item__content {
                // padding-top: 10px;
                // padding-left: 11.5px;
                // padding-bottom: 12.5px;
                border-top: 5px solid #19cbab;
                box-sizing: border-box;
                width: 100%;
                height: 65px;
                /deep/ .el-card {
                  height: 69.5px;
                  /deep/ .el-card__body {
                    position: relative;
                    color: #b2b2b2;
                    padding-top: 10px;
                    padding-left: 11.5px;
                    padding-bottom: 10px;
                    div {
                      line-height: 15px;
                      width: 135px;
                      position: absolute;
                      img {
                        float: left;
                        margin-right: 2.5px;
                      }
                      p {
                        font-size: 12px;
                        font-family: Microsoft YaHei;
                        font-weight: 400;
                        color: rgba(51, 51, 51, 1);
                      }
                    }
                    .edSchool {
                      left: 12.5px;
                      top: 10px;
                    }
                    .edDegree {
                      left: 157px;
                      top: 10px;
                    }
                    .edResour {
                      left: 12.5px;
                      top: 35px;
                    }
                    .edSystem {
                      left: 158px;
                      top: 35px;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>