<template>
  <!-- 这是查看团队页面 viewTeam -->
  <div class="viPage">
      
  </div>
</template>

<script>
export default {
  name: "viewTeam"
};
</script>

<style>
</style>