<template>
  <!-- 这是培训经历  trainExperience    的子界面 -->
  <div class="trExper">
    <p class="one">培训经历</p>
    <div class="timeAxi">
      <!-- 通用培训 时间轴-->
      <div class="inside">
        <p class="exper">通用培训</p>
        <div class="inOne">
          <el-timeline class="insideExper">
            <el-timeline-item
              timestamp="2018/4/12"
              placement="top"
              v-for="(item,index) in insideList "
              :key="index"
            >
              <el-card>
                <h4>{{item.name}}</h4>
                <p>{{item.eve}}</p>
              </el-card>
              <div class="trainCard">
                <div class="trainCardleft">
                  <span class="trOne">成绩</span>
                  <span class="trTwo">98</span>
                </div>
                <div class="trainCardRight">
                  <span class="trOne">培训讲师</span>
                  <span class="trTwo">张三</span>
                </div>
              </div>
            </el-timeline-item>
          </el-timeline>
        </div>
      </div>
      <!-- 项目培训 -->
      <div class="external">
        <p class="exTrain">项目培训</p>
        <p class="exTime">2019</p>
        <div class="exProject">
          <div class="exTitle">CEO助理学习班第一期</div>
          <div class="exContent clearfix">
            <div class="keyEventOne">
              <div class="exLeft">
                <span class="exLeftOne">关键事件1</span>
                <span class="exLeftTwo">:</span>
              </div>
              <div class="exRight">CEO项目管理</div>
            </div>
            <!-- 关键事件2 -->
            <div class="keyEventTwo">
              <div class="exLeft">
                <span class="exLeftOne">关键事件2</span>
                <span class="exLeftTwo">:</span>
              </div>
              <div class="exRight">CEO项目管理</div>
            </div>
            <!--  项目组评价-->
            <div class="keyEventhr">
              <div class="exLeft">
                <span class="exLeftOne">项目组评价</span>
                <span class="exLeftTwo">:</span>
              </div>
            </div>
            <div class="keyComment"></div>
            <!--  -->
            <div class="keyEventfou">
              <div class="exLeft">
                <span class="exLeftOne">导师评价</span>
                <span class="exLeftTwo">:</span>
              </div>
            </div>
            <div class="teachComment"></div>
            <!-- 附件 -->
            <div class="Enclosure">
              <img class="enOne" src="../../assets/svg (1)/svg图标/附件.svg" alt />
              <span>附件</span>
              <img class="enTwo" src="../../assets/svg (1)/svg图标/查看.svg" alt />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "workExperience",
  data() {
    return {
      insideList: [
        {
          name: "培训项目",
          eve: "培训机构"
        },
        {
          name: "培训项目",
          eve: "培训机构"
        }
      ]
    };
  }
};
</script>

<style lang="less" scoped>
.trExper {
  width: 351px;
  margin: 9px auto 0;
  box-sizing: border-box;
  .one {
    line-height: 15px;
    text-align: left;
    margin-bottom: 10px;
    border-left: 5px solid #19cbab;
    padding-left: 9.5px;
    font-size: 14.5px;
  }
  .timeAxi {
    //   通用培训
    .inside {
      .exper {
        width: 72px;
        line-height: 20px;
        background-color: #19cbab;
        text-align: center;
        color: #fff;
        font-size: 12px;
        border-radius: 10px;
        margin-top: 13.5px;
        margin-bottom: 9.5px;
        margin-left: -0.5px;
      }
      .inOne {
        text-align: left;
        margin-left: 13.5px;
        .insideExper {
          .el-timeline-item {
            height: 148.5px;
            padding-bottom: 0;
            /deep/ .el-timeline-item__tail {
              //修改时间纵轴线
              border-left: 2.5px solid #b2b2b2;
              margin-left: -3px;
            }
            /deep/ .el-timeline-item__node {
              //修改时间线圆点尺寸
              width: 6px;
              height: 6px;
              background-color: #b2b2b2;
            }
            /deep/ .el-timeline-item__wrapper {
              padding-left: 11px;
              /deep/ .el-timeline-item__content {
                // padding-top: 10px;
                // padding-left: 11.5px;
                // padding-bottom: 12.5px;
                border-top: 5px solid #19cbab;
                box-sizing: border-box;
                width: 100%;
                height: 65px;
                /deep/ .el-card {
                  height: 69.5px;
                  /deep/ .el-card__body {
                    h4 {
                      color: #b2b2b2;
                    }
                    color: #b2b2b2;
                    padding-top: 10px;
                    padding-left: 11.5px;
                    padding-bottom: 10px;
                  }
                }
                .trainCard {
                  box-sizing: border-box;
                  width: 100%;
                  height: 35px;
                  line-height: 35px;
                  background-color: #fdfdfd;
                  .trainCardleft {
                    height: 100%;
                    width: 153.5px;
                    float: left;
                    box-sizing: border-box;
                    border-right: 1px solid #f2faf9;
                    display: flex;
                    justify-content: space-between;
                    .trOne {
                      font-size: 12px;
                      color: #b2b2b2;
                      margin-left: 13px;
                    }
                    .trTwo {
                      font-size: 10px;
                      margin-right: 22.5px;
                    }
                  }
                  .trainCardRight {
                    width: 153px;
                    display: flex;
                    justify-content: space-between;
                    float: right;
                    .trOne {
                      font-size: 12px;
                      color: #b2b2b2;
                      margin-left: 3.5px;
                    }
                    .trTwo {
                      margin-right: 16.5px;
                      font-size: 12px;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    // 项目培训
    .external {
      .exTrain {
        width: 72px;
        line-height: 20px;
        background-color: #19cbab;
        text-align: center;
        color: #fff;
        font-size: 13px;
        border-radius: 10px;
        margin-top: 13.5px;
        margin-left: -0.5px;
      }
      .exTime {
        text-align: left;
        font-size: 12px;
        // margin-left: 29px;
        margin-top: 15px;
        margin-bottom: 11px;
      }
      .exProject {
        border-top: 5px solid #19cbab;
        width: 100%;
        height: 293px;
        // margin-left: 29px;
        border-radius: 5px 5px 0 0;
        .exTitle {
          color: #19cbab;
          font-family: Microsoft YaHei;
          font-weight: 400;
          line-height: 35px;
          background-color: #f3fcfb;
          font-size: 13px;
        }
        .exContent {
          width: 100%;
          height: 253.5px;
          background-color: white;
          .keyEventOne,
          .keyEventTwo {
            margin-top: 12px;
            font-size: 12px;
            text-align: left;
            line-height: 12px;
            font-family: Microsoft YaHei;
            margin-bottom: 12px;
            .exLeft {
              display: flex;
              justify-content: space-between;
              color: #343434;
              display: inline-block;
              margin-left: 12px;
              width: 63.5px;
              font-weight: 400;
            }
            .exRight {
              color: #b2b2b2;
              display: inline-block;
              margin-left: 12px;
            }
          }
          //
          .keyEventhr {
            margin-top: 12px;
            font-size: 12px;
            text-align: left;
            line-height: 12px;
            font-family: Microsoft YaHei;
            margin-bottom: 6px;
            .exLeft {
              display: flex;
              justify-content: space-between;
              color: #343434;
              display: inline-block;
              margin-left: 12px;
              width: 68.5px;
              font-weight: 400;
            }
          }
          .keyComment {
            width: 283.5px;
            height: 50px;
            border: 1px solid #f5f5f5;
            border-radius: 2px;
            margin-left: 12px;
          }
          //
          .keyEventfou {
            margin-top: 11.5px;
            font-size: 12px;
            text-align: left;
            line-height: 12px;
            font-family: Microsoft YaHei;
            margin-bottom: 6px;
            .exLeft {
              display: flex;
              justify-content: space-between;
              color: #343434;
              display: inline-block;
              margin-left: 12px;
              width: 68.5px;
              font-weight: 400;
            }
          }
          .teachComment {
            width: 283.5px;
            height: 50px;
            border: 1px solid #f5f5f5;
            border-radius: 2px;
            margin-left: 12px;
            margin-bottom: 12px;
          }
          .Enclosure {
            margin-left: 12px;
            width: 93.5px;
            height: 23px;
            background-color: #e8faf6;
            border-radius: 2px;
            line-height: 23px;
            padding-left: 9.5px;
            text-align: left;
            font-size: 9px;
            .enOne {
              width: 13px;
              height: 15px;
              margin-right: 8px;
            }
            .enTwo {
              width: 10px;
              margin-left: 20.5px;
            }
          }
        }
      }
    }
  }
}
</style>