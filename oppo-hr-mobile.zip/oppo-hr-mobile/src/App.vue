<template>
  <div id="app">
    <el-container>
      <el-header style="height:44px">
        <div class="nav">
          <img src="./assets/back.svg" alt />
          <span>履历信息</span>
        </div>
      </el-header>
      <el-main style="height:555px">
        <router-view></router-view>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: "App",
  data() {
    return {};
  }
};
</script>

<style lang="less" scoped>

  .el-header {
    img {
      float: left;
      margin-top: 12px;
      margin-left: 12px;
    }
    background-color: #19cbab;
    color: white;
    text-align: center;
    line-height: 44px;
    padding: 0;
  }
  .el-main {
    padding: 0;
    background-color: #eeeeee;
    color: #333;
    text-align: center;
  }

</style>
