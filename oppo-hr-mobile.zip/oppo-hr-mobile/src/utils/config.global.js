/*
 * @Author: mr.mshao
 * @Date: 2019-06-17 12:50:28
 * @Last Modified by: mr.mshao
 * @Last Modified time: 2019-06-17 12:50:28
 */

import Store from '../store'
const env = process.env.NODE_ENV
const isDev = env === 'development'
const devURL = 'http://113.240.229.3:8118/vapp/' // 开发环境URL
const prodURL = 'http://113.240.229.3:8118/vapp/' // 测试环境
const setUserInfo = function (ENV = isDev) {
  return new Promise((resolve, reject) => {
    if (ENV) {
      // 开发环境
      Store.dispatch('SET_USERINFO', { userId: '235', deptId: '257' })
      resolve()
    } else {
      // 生产环境
      try {
        window.cordova.exec(
          function (obj) {
            Store.dispatch('SET_USERINFO', obj)
            resolve()
          },
          function (e) {
            if (e) { alert(e) } else { alert('获取用户信息失败') }
          }
          , 'UsersInfo', 'getUsersInfo', [])
      } catch (error) {
        alert(error)
      }
    }
  })
}

export default {
  TimeOut: 30000,
  BaseURL: isDev ? devURL : prodURL,
  setUserInfo: setUserInfo
}
