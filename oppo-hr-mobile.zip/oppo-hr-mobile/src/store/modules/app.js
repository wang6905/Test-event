/*
 * @Author: mr.mshao
 * @Date: 2019-06-17 12:49:52
 * @Last Modified by: mr.mshao
 * @Last Modified time: 2019-06-17 12:52:26
 */

export default {
  state: {
    showLoading: false,
    userInfo: {}
  },
  getters: {
    DONE_USERINFO: state => state.userInfo,
    DONE_LOADING: state => state.showLoading
  },
  actions: {
    SET_USERINFO ({ commit }, us) {
      commit('TOGGLE_USERINFO', us)
    },
    SHOW_LOADING ({ commit }) {
      commit('TOGGLE_LOADING', true)
    },
    HIDE_LOADING ({ commit }) {
      commit('TOGGLE_LOADING', false)
    }
  },
  mutations: {
    TOGGLE_USERINFO (state, us) {
      state.userInfo = { ...us }
    },
    TOGGLE_LOADING (state, flag) {
      state.showLoading = flag
    }
  }
}
