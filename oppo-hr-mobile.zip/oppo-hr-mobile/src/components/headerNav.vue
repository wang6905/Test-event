<template>
  <div class="headerNav">
      <div class="headerLeft">
          <img src="../assets/svg (1)/svg图标/名片.svg" alt="">
          <span>人力资源部总经理</span>
      </div>
      <div class="headerRight">
          <img src="../assets/temp/1.jpg" alt="">
          <span>张心云</span>
      </div>
  </div>
</template>

<script>
export default {
name:'headerNav'
}
</script>

<style lang="less" scoped>
    .headerNav{
        height: 35px;
        color: black;
        display: flex;
        .headerLeft{
            img{
                width: 20px;
            }
        }
        .headerRight{
             img{
                width: 20px;
            }
        }
    }
</style>