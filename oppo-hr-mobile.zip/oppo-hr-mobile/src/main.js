// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router/router.js'
import store from './store'
import Antd from 'ant-design-vue' //导入ant组件库
import 'ant-design-vue/dist/antd.css'
Vue.use(Antd)   //引入anted//导入ant组件css
import 'amfe-flexible/index.js'  //适配
// 导入移动端适配
import ElementUI from 'element-ui' //element
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)
import config from './utils/config.global'
import VConsole from 'vconsole'
import { Button, Row, Col, Icon, Swipe, SwipeItem, Uploader, ActionSheet, Overlay } from 'vant';
import "../src/assets/basecss/basecss.css"
// import messageOne1 from './views/message/messageOne1.vue'    //全局自定义组件
// Vue.component('messageOne',messageOne1)     //全局自定义组件
import headerNav1 from '../src/components/headerNav.vue'    //顶部导航全局自定义组件
import performInformat1 from './views/performInformat/performInformat.vue'    //绩效信息组件
import qualificat1 from './views/qualificat/qualificat.vue'    //任职资格组件
import workExperience1 from './views/workExperience/workExperience.vue'    //工作经历组件
import educatExperience1 from './views/educatExperience/educatExperience.vue'    //教育经历组件
import languageInformat1 from './views/languageInformat/languageInformat.vue'    //语言信息组件
import testReview1 from './views/testReview/testReview.vue'    //测评及评审组件
import talentInventory1 from './views/talentInventory/talentInventory.vue'    //人才盘点组件
import trainExperience1 from './views/trainExperience/trainExperience.vue'    //培训经历组件
Vue.component('performInformat', performInformat1)        //绩效信息组件
Vue.component('headerNav', headerNav1)   //顶部导航全局自定义组件
Vue.component('qualificat', qualificat1)   //任职资格组件
Vue.component('workExperience', workExperience1)   //工作经历组件
Vue.component('educatExperience', educatExperience1)   //教育经历组件
Vue.component('languageInformat', languageInformat1)   //语言信息组件
Vue.component('testReview', testReview1)   //测评及评审组件
Vue.component('talentInventory', talentInventory1)   //人才盘点组件
Vue.component('trainExperience', trainExperience1)   //培训经历组件
Vue.use(Row).use(Col);
Vue.use(Button);
Vue.use(Icon);
Vue.use(Swipe).use(SwipeItem); //轮播图
Vue.use(ActionSheet);
Vue.use(Overlay);
// let vConsole = new VConsole();
Vue.config.productionTip = false
/* eslint-disable no-new */
import VueRouter from 'vue-router'
Vue.use(VueRouter)
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
