<template>
  <div id="app">
    <van-row type="flex" justify="space-between">
      <van-col span="6"><van-icon name="arrow-left" /></van-col>
      <van-col span="6">履历信息</van-col>
      <van-col span="6" style="text-align:center"><img style="height:25px;" src="../src/assets/fix.jpg" alt=""></van-col>
    </van-row>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "App",
  data() {
    return {

    };
  }
};
</script>

<style lang="less">

</style>
