<template>
  <!----------人才基本信息---------这是一个自定义组件  可复用   这是部分 -->
  <div class="msAll">
    <!-- 放照片那一栏名字拼音,英文名字那一栏 -->
    <div class="photoTop">
      <img src="../../assets/temp/1.jpg" alt style="width:70px;height:120px" />
      <p>
        <span class="leftColor">名字拼音</span>
        <span>11111111111</span>
      </p>
      <p>
        <span class="leftColor">英文名字</span>
        <span>11111111111</span>
      </p>
      <p>
        <span class="leftColor">员工编号</span>
        <span>11111111111</span>
      </p>
      <p>
        <span class="leftColor">出生日期</span>
        <span>11111111111</span>
      </p>
    </div>
    <!-- 下面的国籍,名族,婚姻,籍贯,性别,入职日期,系统,中心,部门,小组等.. -->
    <div class="msT">
      <!-- 第一列 -->
      <div class="one">
        <span class="leftColor">国籍</span>
        <span>中国</span>
        <span class="leftColor">民族</span>
        <span>汉族</span>
        <span class="leftColor">婚姻状况</span>
        <span>未婚</span>
      </div>
      <div class="two">
        <span class="leftColor">籍贯</span>
        <span>中国</span>
        <span class="leftColor">性别</span>
        <span>女</span>
      </div>
      <div class="three">
        <span class="leftColor">工作城市</span>
        <span>深圳</span>
        <span class="leftColor">纳税单位</span>
        <span>OPPO</span>
      </div>
      <div class="four">
        <span class="leftColor">招聘方式</span>
        <span>校招</span>
        <span class="leftColor">员工类型</span>
        <span>正式员工</span>
      </div>
      <div class="five">
        <span class="leftColor">入职日期</span>
        <span>--</span>
        <span class="leftColor">离职日期</span>
        <span>--</span>
      </div>
      <div class="six">
        <span class="leftColor">离职原因</span>
        <span>--</span>
      </div>
      <div class="seven">
        <span class="leftColor">系 &nbsp; &nbsp; 统</span>
        <span>人力资源系统</span>
      </div>
      <div class="eight">
        <span class="leftColor">中 &nbsp; &nbsp;心</span>
        <span>薪酬中心</span>
      </div>
      <div class="nin">
        <span class="leftColor">部 &nbsp; &nbsp;门</span>
        <span>人力资源部</span>
      </div>
      <div class="ten">
        <span class="leftColor">小 &nbsp; &nbsp;组</span>
        <span>薪酬小组</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "messageOne1",
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="less" scoped>
.msAll {
  font-size: 16px;
  width: 345px;
//   height: 400px;
  background-color: aliceblue;
  margin: 5px auto;
  padding-left: 10px;
  padding-top: 5px;
  .msT {
    .leftColor {
      color: gray;
    }
  }
  .photoTop {
    height: 120px;
    img {
      float: left;
    }
    p {
      float: left;
      .leftColor {
        color: gray;
        margin-left: 6px;
      }
    }
  }
}
</style>