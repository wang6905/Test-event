<template>
  <!-- ----------- 证件信息----------- 这是一个自定义组件 可复用(后面用父子组件传值来获得数据)-->
  <div class="certiAll">
    <!--因为有大概十几个title 证件信息title这里如果要复用的话可用 v-if 和 v-else-if 来改变证件信息来达到复用目的-->
    <p class="certiTitle">证件信息</p>
    <div class="certi" v-for="item in certiList" :key="item.id">
      <div class="certiContent">
        <span class="leftColor">{{item.nationality}}</span>
        <span>{{item.name}}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "certiMessage",
  data() {
    return {
      certiList: [
        {
          id: '1',
          nationality: "国籍",
          name: "中国"
        },
        {
          id: '2',
          nationality: "国籍",
          name: "中国"
        }
      ]
    };
  },
  methods: {}
};
</script>

<style lang="less" scoped>
.certiAll {
  .certiTitle{
    border-left: 3px solid skyblue;
    padding-left: 8px;
  }
  margin: 0 auto;
  font-size: 16px;
  width: 345px;
  background-color: aliceblue;
  padding-left: 10px;
  padding-top: 5px;
  .certi {
    .certiContent {
      display: flex;
      .leftColor {
        color: gray;
      }
    }
  }
}
</style>