<template>
  <div class="all">
    <van-row type="flex" style="padding-left:10px">
      <van-col span="12" style="padding-left:10px;border-left:1px solid black">我的团队</van-col>
      <van-col span="12">
        <van-row type="flex" justify="end" style="text-align:center">
          <van-col span="12">
            <img style="height:24px" src="../assets/fix.jpg" alt />
          </van-col>
          <van-col span="12">王晓华</van-col>
        </van-row>
      </van-col>
    </van-row>
    <!-- 搜索查询员工 -->
    <div class="nameOfGueter">
      <input
        style="text-align:center"
        onfocus="this.placeholder=''"
        class="name"
        type="text"
        placeholder="请输入查询员工姓名或ID"
      />
      <img src="../assets/fix.jpg" alt style="height:24px" />
    </div>
    <!-- 团队组成 -->
    <div class="teamForm" v-for="item in nameList">
      <span>{{item.name}}</span>
      <span>111</span>
      <span>{{item.age}}</span>
      <van-button type="info">信息按钮</van-button>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: "home",
  data() {
    return {
      nameList: [
        { name: "jake", age: "11" },
        { name: "chen", age: "13" },
        { name: "gang", age: "15" },
        { name: "gang", age: "15" }
      ]
    };
  }
};
</script>
<style lang="less" scoped>
.all {
  .teamForm {
    width: 350px;
    height: 40px;
    border: 1px solid black;
    font-size: 16px;
    line-height: 30px;
    vertical-align: center;
    margin-bottom: 10px;
    span {
      margin-left: 10px;
    }
    button {
      margin-left: 20px;
      padding: 0;
      height: 40px;
    }
  }
  .nameOfGueter {
    //  padding-left: 25px;
    .name {
      margin-left: 20px;
      width: 300px;
      height: 33px;
      border-radius: 3px;
    }
  }
}
</style>