<template>
  <!-- 滑块测试 -->

  <!-- -->
  <div class="baseAll">
    <!-- 基本信息nav -->
    <div class="base">
      <!-- 左边 -->
      <div class="left">
        <img src="../assets/temp/1.jpg" alt style="width:24px" />
        <span>基本信息</span>
      </div>
      <!-- 右边 -->
      <div class="right">
        <img src="../assets/temp/1.jpg" alt style="width:24px" />
        <span>张心云</span>
      </div>
    </div>
    <!-- 自定义组件 -->
    <messageOne></messageOne>
    <certiMessage></certiMessage>
   </div>
</template>

<script>

export default {
  name: "baseMessage",
  data() {
    return {
     
    };
  },
  
  methods: {
   
   
  }
};
</script>

<style lang="less" scoped>
.baseAll {
  .base {
    display: flex;
    justify-content: space-between;
  }
}
</style>