// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router/router.js'
import store from './store'
import 'amfe-flexible/index.js' // 导入移动端适配
import config from './utils/config.global'
import VConsole from 'vconsole'
import { Button,Row, Col,Icon,Swipe, SwipeItem} from 'vant';
import "../src/assets/basecss/basecss.css"
import messageOne1 from './views/message/messageOne1.vue'//全局自定义组件
import certiMessage1 from './views/message/certiMessage1.vue'//全局自定义组件
import VueTouch from 'vue-touch'//测试滑块组件
Vue.use(VueTouch, {name: 'v-touch'})//测试滑块组件
Vue.component('messageOne',messageOne1)//全局自定义组件
Vue.component('certiMessage',certiMessage1)//全局自定义组件
Vue.use(Row).use(Col);
Vue.use(Button);
Vue.use(Icon);
Vue.use(Swipe).use(SwipeItem);//轮播图
// let vConsole = new VConsole();
Vue.config.productionTip = false
/* eslint-disable no-new */
import VueRouter from 'vue-router'
Vue.use(VueRouter)
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
