import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)
import home from '../views/Home.vue'
import baseMessage from '../views/baseMessage.vue'
// import certiMessage1 from '../views/message/certiMessage1.vue'



const routes = [
  { path: '/', 
  redirect: { name: 'home' }},
  {
    path: '/home',
    name: 'home',
    component: home,
  },
  {
    path: '/baseMessage',
    name: 'baseMessage',
    component: baseMessage,
  },
  // {
  //   path: '/certiMessage1',
  //   name: 'certiMessage1',
  //   component: certiMessage1,
  // },

]

const router = new VueRouter({
  routes
})

export default router
