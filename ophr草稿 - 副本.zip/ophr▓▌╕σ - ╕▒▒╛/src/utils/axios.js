const axios = require('axios')

export function axs (url, data) {
  return axios.post(url, data).then(
    (r) => {
      let errCode = r.errCode || r.data.errCode
      let lookupCodes = r.data.lookupCodes || r.lookupCodes
      if (errCode == 'S') {    // 成功即返回数据
        return r
      }
      else if(errCode == 'F'){
        return r
      }
      else if(lookupCodes){   //数据字典查询码不为空返回数据
        return r
      }
      else{
        alert("进入成功的回调，但获取数据失败")
      }
    },
    (r)=>{
      let errCode = r.errCode || r.data.errCode
      let errMsg = r.errMsg || r.data.errMsg
      alert(errCode+errMsg)
    }
  )
}
