<template>
  <div class="title">
    <img class="back-img" src="../assets/back.svg" @click="back()">
    <span class="title-text">{{dmTitle}}</span>
  </div>
</template>

<script>
import wpt from '../utils/wpt'
export default {
  data(){
    return{

    }
  },
  props:['dmTitle'],
  methods:{
    back(){
      let hash = window.location.hash;
      if(hash =='#/mainPage'){
        this.closeApp();
      }else{
        this.$router.back(-1);
      }
    },
    closeApp(){
      wpt.closeApp(function(msg) {
        // alert(msg);
      }, function(e) {
        alert("Error: " + e);
      },{});
    }
  }
}
</script>

<style lang="scss" scoped>
.title{
  width: 100%;
  height: 46px;
  background-color: #ffffff;
  position: fixed;
  z-index: 99999;
  top: 0;
  left: 0;
  font-size:18px;
  font-family : PingFangSC-Medium;
  font-weight:500;
  color:rgba(51,51,51,1);
  .back-img{
    padding: 15px;
  }
  .title-text{
    font-size: 18px;
    position: absolute;
    top: 10.5px;
    left: calc(50% - 18px);
  }
}
</style>
