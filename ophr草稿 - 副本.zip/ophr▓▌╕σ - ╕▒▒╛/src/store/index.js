/*
 * @Author: mr.mshao
 * @Date: 2019-02-15 10:08:41
 * @Last Modified by: mr.mshao
 * @Last Modified time: 2019-06-17 12:52:04
 */

import Vue from 'vue'
import Vuex from 'vuex'
import APP from './modules/app'
const debug = process.env.NODE_ENV !== 'production'
Vue.use(Vuex)

export default new Vuex.Store({
  strict: debug,
  modules: {
    'app': APP
  }
})
