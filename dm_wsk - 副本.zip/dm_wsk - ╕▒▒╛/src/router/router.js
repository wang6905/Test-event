import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

const mainPage = r => require.ensure([],() => r (require('@/views/mainPage.vue')),'mainPage')
const addFix = r => require.ensure([],() => r (require('@/views/addFix.vue')),'addFix')
const fixDetails = r => require.ensure([],() => r (require('@/views/fixDetails.vue')),'fixDetails')
const serviceDetails = r => require.ensure([],() => r (require('@/views/serviceDetails.vue')),'serviceDetails')
const evaluate = r => require.ensure([],() => r (require('@/views/evaluate.vue')),'evaluate')

const routes = [
   {
     path:'/mainPage',
     component: mainPage,
   },
   {
     path: '/addFix',
     name:'addFix',
     component: addFix
   },
   {
     path: '/fixDetails',
     name: 'fixDetails',
     component: fixDetails
   },
   {
     path: '/serviceDetails',
     name: 'serviceDetails',
     component: serviceDetails
   },
   {
     path: '/evaluate',
     name: 'evaluate',
     component: evaluate
   },
   {
     path:'/',
     redirect:'/mainPage'
   }
]

const router = new VueRouter({
        routes
})

export default router
