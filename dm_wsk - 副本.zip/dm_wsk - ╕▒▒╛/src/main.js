// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router/router.js'
import store from './store'
import config from './utils/config.global'
import VConsole from 'vconsole'

import  { Loading, TransferDom, LoadingPlugin, Toast, ToastPlugin } from 'vux'

// let vConsole = new VConsole();
Vue.component('loading', Loading)
Vue.directive('transfer-dom', TransferDom)
Vue.use(LoadingPlugin)
Vue.component('toast', Toast)
Vue.use(ToastPlugin)

Vue.config.productionTip = false
/* eslint-disable no-new */
document.addEventListener('deviceready', function () {
  config.setUserInfo().then(() => {
    new Vue({
      el: '#app',
      router,
      store,
      components: { App },
      template: '<App/>'
    })
  })
})
