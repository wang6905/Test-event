<template>
  <div class="serviceDetails">
    <dm-header :dm-title="title"></dm-header>
    <div class="serDetail-contain">
      <div class="serviceMsg">
        <table class="msg-table">
          <tbody>
            <tr>
              <td class="name">故障类型：</td>
              <td class="data">{{repairInfo.lookupName}}</td>
            </tr>
            <tr>
              <td class="name">联系人：</td>
              <td class="data">{{repairInfo.contactName}}</td>
            </tr>
            <tr>
              <td class="name">期望服务时间：</td>
              <td class="data">{{repairInfo.serviceTime}}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="servicePic">
        <p class="static-p">现场图片</p>
        <div class="pic-contain">
          <img :src="i.pictruePath" class="pic" v-for="(i,index) in pictureInfo" @click="showPic(index)">
          <div v-transfer-dom>
            <previewer :list="currentSrc" ref="picShow"></previewer>
          </div>
        </div>
        <div class="desc">{{repairInfo.breakdownDescription}}</div>
      </div>
    </div>
  </div>
</template>

<script>
import dmHeader from '../components/header.vue'
import Tab from "vux/src/components/tab/tab";
import {Previewer,TransferDom } from 'vux'
import {queryRepairDetail} from '../utils/requestData'
export default {
  components: {
    dmHeader,
    Tab,
    Previewer
  },
  data () {
    return {
      title:'服务详情',
      repairInfo:{},
      pictureInfo:[],
      currentSrc:[{
        src:''
      }],
      options: {
        getThumbBoundsFn(index) {
          let thumbnail = document.querySelectorAll('.previewer-demo-img')[index]
          let pageYScroll = window.pageYOffset || document.documentElement.scrollTop
          let rect = thumbnail.getBoundingClientRect()
          return {x: rect.left, y: rect.top + pageYScroll, w: rect.width}
        }
      }
    }
  },
  directives: {
    TransferDom
  },
  methods: {
    async showServiceDetail(){
      this.$vux.loading.show({ text: '加载中...'})
      let res = await queryRepairDetail(this.repairId);
      this.$vux.loading.hide()

      this.repairInfo = res.data.repairInfo[0];
      this.pictureInfo = res.data.pictureInfo;
    },
    showPic (index) {
      this.currentSrc[0].src = this.pictureInfo[index].pictruePath;
      // console.log(this.pictureInfo[index]);
      this.$refs.picShow.show(0)
    },
  },
  mounted(){
    this.repairId = this.$route.params.repairId;
    this.showServiceDetail();
  }
}
</script>

<style lang="scss" scoped>
.serviceDetails{
  width: 100%;
  height: 100%;
  overflow: hidden;
  background-color: #f9f9f9;
}
.serDetail-contain{
  width: 100%;
  height: 100%;
  margin-top: 61px;
  .serviceMsg{
    width: calc(100% - 30px);
    height: 92px;
    background-color: #fff;
    margin: 15px auto;
    padding-top: 12px;
    padding-bottom: 6px;
    .msg-table{
      margin-left: 15px;
      tr{
        display: block;
        margin-bottom: 6px;
        font-size:14px;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        td{
          padding: 0;
        }
        .name{
          width:110px;
          color:#999999;
        }
        .data{
         color: #333;
        }
      }
    }
  }
  .servicePic{
    width: calc(100% - 30px);
    min-height: 224px;
    margin: 0 auto;
    background-color: #fff;
    padding-top: 15px;
    padding-bottom: 40px;
    .static-p{
      font-size:14px;
      font-family:PingFang-SC-Regular;
      font-weight:400;
      color: #999999;
      margin:0 0 0 15px;
      display: block;
    }
    .pic-contain{
      width:calc(100% - 30px);
      display: flex;
      display: -webkit-flex;
      flex-direction: row;
      flex-wrap: wrap;
      flex-grow: 0;
      flex-shrink: 0;
      /*overflow-x: scroll;*/
      margin: 15px auto;
      .pic{
        width: 60px;
        height: 60px;
        margin-right: 10px;
        margin-bottom: 10px;
        object-fit: cover;
        border: 1px solid #ccc;
        border-radius: 3px;
      }
    }
    .desc{
      font-size:14px;
      font-family:PingFang-SC-Regular;
      font-weight:400;
      color:#333333;
      width:calc(100% - 30px);
      margin: 0px auto;
      word-break: break-word;
    }
  }

}
</style>
