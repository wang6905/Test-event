<template>
  <div class="detail-position">
    <div class="fixPage-head">
      <dm-header :dm-title="title"></dm-header>
      <tab bar-active-color="#CE715E" active-color="#333333" :line-width="3" custom-bar-width="60px">
        <tab-item selected @on-item-click="goPage('serviceDetails')">基本信息</tab-item>
        <tab-item @on-item-click="goPage('fixDetails')">跟踪服务</tab-item>
      </tab>
    </div>
    <div class="fixDetails">
      <!--<router-view></router-view>-->
      <div v-show="serviceDetails" class="serDetail-contain">
        <div class="serviceMsg">
          <table class="msg-table">
            <tbody>
            <tr>
              <td class="name">故障类型：</td>
              <td class="data">{{repairInfo.lookupName}}</td>
            </tr>
            <tr>
              <td class="name">联系人：</td>
              <td class="data">{{repairInfo.contactName}}</td>
            </tr>
            <tr>
              <td class="name">期望服务时间：</td>
              <td class="data">{{repairInfo.serviceTime | showDateFilter}}</td>
            </tr>
            </tbody>
          </table>
        </div>
        <div class="servicePic">
          <p class="static-p">现场图片</p>
          <div class="pic-contain">
            <img :src="i.pictruePath" class="pic" v-for="(i,index) in pictureInfo" @click="showPic(index)">
            <div v-transfer-dom>
              <previewer :list="currentSrc" ref="previewer"></previewer>
            </div>
          </div>
          <div class="desc">{{repairInfo.breakdownDescription}}</div>
        </div>
      </div>
      <div v-show="!serviceDetails" id="fixDetail-contain">
        <div class="fixDetail-content">
          <div class="fix-message">
            <img class="fix-icon" src="../assets/file-minus-2.svg"/>
            <table class="msg-table">
              <tbody>
              <tr>
                <td class="first_td">移动编号：</td>
                <td class="second_td">{{repairInfo.repairNumber}}</td>
              </tr>
              <!--<tr>-->
                <!--<td class="first_td">OA服务单号：</td>-->
                <!--<td class="second_td">{{repairInfo.repairNumber}}</td>-->
              <!--</tr>-->
              <tr>
                <td class="first_td">工单状态：</td>
                <td class="second_td">{{repairInfo.status | stFilter}}</td>
              </tr>
              <tr>
                <td class="first_td">楼号：</td>
                <td class="second_td">{{repairInfo.buildingNumber}}</td>
              </tr>
              <tr>
                <td class="first_td">房间号：</td>
                <td class="second_td">{{repairInfo.houseNumber}}</td>
              </tr>
              </tbody>
            </table>
          </div>
          <div class="fix-timeline">
            <div class="datetime">
              <ul>
                <li class="time-item" :class="{active:key==0}" v-for="(iTime,key) in processInfo">
                  <p>{{iTime.progressTime | dateShowByType('date')}}</p>
                  <p class="hm-time">{{iTime.progressTime | dateShowByType('time')}}</p>
                </li>
              </ul>
            </div>
            <div class="timeline-content">
              <ul>
                <li class="content-item" v-for="(iContent,key) in processInfo">
                  <div class="topItem" v-if="key==0"></div>
                  <p class="tit">{{iContent.progressDescription}}</p>
                  <p class="detail">操作人：{{iContent.progressOperator}}</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="seek-btn" @click="toServiceDetails()">查看服务详情</div>
      </div>
    </div>
  </div>

</template>

<script>
  import dmHeader from '@/components/header.vue'
  import {queryRepairDetail} from '../utils/requestData'
  import { Tab, TabItem, Previewer,TransferDom } from 'vux'

    export default {
       data(){
         return {
           title: '报修',
           repairId:'',
           serviceDetails: true,
           repairInfo: {},
           pictureInfo: [],
           processInfo: [],
           currentSrc:[{
             src:''
           }],
           options: {
             getThumbBoundsFn(index) {
               let thumbnail = document.querySelectorAll('.previewer-demo-img')[index]
               let pageYScroll = window.pageYOffset || document.documentElement.scrollTop
               let rect = thumbnail.getBoundingClientRect()
               return {x: rect.left, y: rect.top + pageYScroll, w: rect.width}
             }
           }
         }
       },
      directives: {
        TransferDom
      },
      components:{
        'dm-header':dmHeader,
        Tab,
        TabItem,
        Previewer
      },
      computed:{
        reverseArray(){
          return this.sortProcessArrByDateDesc();
        }
      },
      filters:{
        stFilter:function (statusNum) {
           switch (statusNum){
             case 1:
               return '提单';
             case 2:
               return '处理中';
             case 3:
               return '完成维修';
             case 4:
               return '已评价';
           }
        },
        dateShowByType:function (time,type) { // type: date xx-xx  time xx:xx
          // console.log("t",new Date(time));
          let t = new Date(time.replace(/-/g,'/'));
          if (type == 'date'){
            return (t.getMonth()+1<10
              ? '0'+(t.getMonth()+1):(t.getMonth()+1)) + '-'+ (t.getDate()<10
              ? '0'+ t.getDate():t.getDate());
          }else if(type == 'time'){
            return (t.getHours()<10
              ? '0'+t.getHours():t.getHours()) + ":" + (t.getMinutes() < 10
              ? '0'+ t.getMinutes():t.getMinutes());
          }
        },
        showDateFilter:function (time) { // 只返回YYYY-MM-DD
            return time.substring(0,11);
        }
      },
      methods:{
        goPage(name){
          if (name == 'serviceDetails') {
            this.serviceDetails = true;
          }else if(name == 'fixDetails'){
            this.serviceDetails = false;
          }
        },
        async showDetail(repairId){
          this.$vux.loading.show({ text: '加载中...'});
          let res = await queryRepairDetail(repairId);
          this.$vux.loading.hide();

          this.repairInfo = res.data.repairInfo[0];
          this.pictureInfo = res.data.pictureInfo;
          this.processInfo = res.data.processInfo;
          this.sortProcessArrByDateDesc();
        },
        sortProcessArrByDateDesc(){
          if (this.processInfo.length <= 1) {
            return this.processInfo;
          }
          this.processInfo = this.processInfo.sort((a,b) => {
            if (new Date(a) < new Date(b)){
              return 1;
            }else {
              return -1;
            }
          })
          return this.processInfo;
        },
        showPic (index) {
          this.currentSrc[0].src = this.pictureInfo[index].pictruePath;
          this.$refs.previewer.show(0)
        },
        toServiceDetails(){
          this.$router.push({
            'name':'serviceDetails',
            params:{
              repairId: this.repairId}
          })
        }
      },
      mounted(){
         this.repairId = this.$route.params.repairId;
         if (this.repairId){
           window.sessionStorage.setItem("page_repairId", this.repairId);
         }else {
           this.repairId = window.sessionStorage.getItem("page_repairId");
         }
         this.showDetail(this.repairId);
      }
    }
</script>

<style lang="scss" scoped>
.detail-position{
  overflow: hidden;
}
.fixPage-head>div:last-child{
  margin-top: 46px;
}
.fixPage-head{
  .vux-tab-wrap .vux-tab-container .vux-tab{
    background-color: #F9F9F9;
    height: 40px;
    .vux-tab-item{
      line-height: 40px;
      color: #333;
      background:#F9F9F9;
    }
  }
}
.fixDetails{
  width: 100%;
  height: calc(100% - 46px - 44px);
  position: absolute;
  left: 0;
  background-color: #F9F9F9;
}
.serDetail-contain{
  width: 100%;
  height: calc(100% - 15px);
  //padding-top: 15px;
  .serviceMsg{
    width: calc(100% - 30px);
    height: 92px;
    background-color: #fff;
    margin: 15px auto;
    padding-top: 12px;
    padding-bottom: 6px;
    .msg-table{
      margin-left: 15px;
      tr{
        display: block;
        margin-bottom: 6px;
        font-size:14px;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        td{
          padding: 0;
        }
        .name{
          width:110px;
          color:#999999;
        }
        .data{
          color: #333;
        }
      }
    }
  }
  .servicePic{
    width: calc(100% - 30px);
    min-height: 224px;
    margin: 0 auto;
    background-color: #fff;
    padding-top: 15px;
    padding-bottom: 40px;
    .static-p{
      font-size:14px;
      font-family:PingFang-SC-Regular;
      font-weight:400;
      color: #999999;
      margin:0 0 0 15px;
      display: block;
    }
    .pic-contain{
      width:calc(100% - 30px);
      display: flex;
      display: -webkit-flex;
      flex-direction: row;
      /*flex-wrap: nowrap;*/
      /*overflow-x: scroll;*/
      margin: 15px auto;
      flex-wrap: wrap;
      flex-grow: 0;
      flex-shrink: 0;
      .pic{
        width: 60px;
        height: 60px;
        margin-right: 10px;
        margin-bottom: 10px;
        /*margin-bottom: 2px;*/
        object-fit: cover;
        border: 1px solid #ccc;
        border-radius: 3px;
      }
    }
    .desc{
      font-size:14px;
      font-family:PingFang-SC-Regular;
      font-weight:400;
      color:#333333;
      width:calc(100% - 30px);
      margin: 0px auto;
      /*white-space: pre-wrap;*/
      /*word-break: break-all;*/
      word-break: break-word;
    }
  }

}
#fixDetail-contain{
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  .fixDetail-content{
    height: calc(100% - 119px);
    text-align: center;
    margin-top: 15px;
    margin-bottom: 15px;
    .fix-message{
      background-color: #fff;
      width: calc(100% - 30px);
      height: 127px;
      margin: 0 auto;
      position: relative;
      .fix-icon{
        position: absolute;
        left: 16px;
        top: 16px;
        width: 15px;
        height: 15px;
      }
      .msg-table{
        margin-left: 36px;
        margin-top: 15px;
        font-size: 14px;
        font-family:PingFang-SC-Regular;
      }
      tr{
        display: block;
        margin-bottom: 5px;
        &:first-child{
          margin-top: 10px;
        }
        td{
          font-size: 14px;
          padding: 0;
          &.first_td{
            color: #999999;
            text-align: left;
            width: 72px;
          }
          &.second_td{
            color: #333333;
          }
        }
      }
    }
    .fix-timeline{
      width: calc(100% - 30px);
      max-height: calc(100% - 142px);
      background-color: #fff;
      margin: 0 auto;
      overflow-y: auto;
      margin-top: 15px;
      //margin-bottom: 15px;
      display: flex;
      display: -webkit-flex;
      .datetime{
        width: 60px;
        height: 100%;
        margin-top: 20px;
        ul{
          padding: 0;
        }
        .time-item{
          list-style: none;
          text-align: right;
          font-size:10px;
          color: #999999;
          //margin-bottom: 40px;
          padding-right: 10px;
          height: 82px;
          font-family:Arial;
          &.active{
            color: #333333;
            font-size: 14px;
            .hm-time{
              font-size: 13px;
            }
          }
          p{
            margin: 0;
            padding: 0;
          }
        }
      }
      .timeline-content{
        flex-grow:1;
        margin-left: 8px;
        margin-top: 20px;
        font-family:PingFang-SC-Regular;
        position: relative;
        .topItem{
          width: 13px;
          height: 13px;
          position: absolute;
          background-color: #CE715E;
          left: -6px;
          top:16px;
          border-radius: 13px;
        }
        ul{
          padding: 0;
        }
        .content-item{
          list-style: none;
          text-align: left;
          height: 80px;
          text-indent: 14px;
          p{
            margin: 0;
            padding: 0;
            color: #333333;
            &.tit{
              font-size: 14px;
              padding-bottom: 10px;
            }
            &.detail{
              font-size: 12px;
              padding-bottom: 2px;
            }
          }
          border-left: #CE715E 1px solid;
          &:last-child{
            border-left:0;
            p{
              border-left: #CE715E 1px solid;
            }
          }
        }
      }
    }
  }
  .seek-btn{
    width: calc(100% - 30px);
    height: 40px;
    background-color: #fff;
    border-radius:21px;
    text-align: center;
    line-height: 40px;
    font-size:14px;
    font-family:PingFangSC-Medium;
    font-weight:500;
    color: #333;
    margin:0 auto;
  }
}

</style>
