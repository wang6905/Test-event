<template>
  <div class="main-page">
    <dm-header :dm-title="title"></dm-header>
    <tab class="tab" :line-width="1" custom-bar-width="60px">
      <tab-item selected @on-item-click="clickAll()">全部</tab-item>
      <tab-item @on-item-click="clickDone()">已完成</tab-item>
    </tab>
     <div class="mlist">
      <pull-to @infinite-scroll="loadMore">
        <div class="mlist-cell" v-for="(item, index) in repairInfo" :key="index">
          <div class="list-top">
            <div class="list-top-icon">
              <img class="list-top-img" src="../assets/number.svg">
            </div>
            <div class="list-top-number">
              {{item.repairNumber}}
            </div>
            <div class="list-top-status">
              {{statusFilter(item.status)}}
            </div>
          </div>
          <div class="list-body" @click="toFixDetails(item.repairId)">
            <img class="list-body-img" :src="item.pics[0].pictruePath || defaultShow" @error="showDefault(index)">
            <div class="list-body-center">
              <div class="list-body-title">{{item.lookupName}}</div>
              <div class="list-body-time">{{item.creationDate}}</div>
            </div>
            <img class="list-body-icon" src="../assets/right.svg">
          </div>
          <div class="list-bottom">
            <span class="list-bottom-phone">服务热线</span>
          </div>
          <div v-show="item.status == 3" class="list-evaluation">
            <div class="evaluation-button" @click="toEvaluate(index)">
              评价
            </div>
          </div>
          <div v-show="item.status == 2" class="list-evaluation">
            <div class="evaluation-button" @click="toComplete(index)">
              完成维修
            </div>
          </div>
        </div>
        <Divider v-if="isLast">我是有底线的</Divider>
      </pull-to>
     </div>
    <div class="mbutton" @click="toAddFix()">新建报修单</div>
  </div>
</template>

<script>
import {
  queryRepairList,
  finishRepair,
} from '../utils/requestData'

import {
  Tab,
  TabItem,
  Divider
} from 'vux'

import PullTo from 'vue-pull-to'
import dmHeader from '@/components/header.vue'
const defaultPic = require('../assets/fix.jpg')
import wpt from '../utils/wpt'

export default {
  data(){
    return{
      title: '报修',
      pageIndex: 0,
      pageSize: 4,
      status: '',  //单据状态
      // userId: '',  //用户id
      userId: 1332,  //PC调试userId
      username: '',  //用户姓名
      repairInfo: [], //单据列表
      isLast: false,  //是否加载到底
      defaultShow : defaultPic
    }
  },
  components:{
    'dm-header': dmHeader,
    PullTo,
    Tab,
    TabItem,
    Divider
  },
  mounted(){
    // var self = this;
    // wpt.getUserInfo(function (info) {
    //   self.userId = info.userId;
    //   self.username = info.username;
    //   self.queryFixList();
    // },function (err) {
    //   alert('ERROR-'+ err);
    // })
    this.queryFixList()  //PC调试
  },
  methods:{
    //点击新建报修单按钮触发
    toAddFix(){
      this.$router.push({name:'addFix',params:{userId:this.userId,userName:this.username}})
    },
    //查询单据列表
     async queryFixList(){
      // debugger
      if(this.isLast == true){
        return
      }
      this.$vux.loading.show({ text: '加载中...'})
      try{
        var res = await queryRepairList( this.pageIndex, this.pageSize, this.status, this.userId)
      }
      catch(e){
        alert('异步请求异常')
      }
      this.$vux.loading.hide()
      res.data.repairInfo.forEach( r => {
        this.repairInfo.push(r)
      })
      this.isLast = res.data.isLast
      this.pageIndex++
    },
    //单据状态过滤器
    statusFilter(statusNum){
      switch(statusNum){
        case 1: return '提单';
        case 2: return '处理中';
        case 3: return '完成维修';
        case 4: return '已评价';
        default: console.log('未找到对应项');
      }
    },
    //点击跳转到评价页面
    toEvaluate(idx){
      this.$router.push({
        name: 'evaluate',
        params: {
          userId: this.userId,
          username: this.username,
          repairId: this.repairInfo[idx].repairId
        }
      })
    },
    //下拉加载更多
    loadMore(){
         this.queryFixList();
    },
    //点击tab的“全部”触发
    async clickAll(){
      this.status = ''
      this.pageIndex = 0
      this.isLast = false
      this.repairInfo = []
      await this.queryFixList()
    },
    //点击tab的“已完成”触发
    async clickDone(){
      this.status = 3
      this.pageIndex = 0
      this.isLast = false
      this.repairInfo = []
      await this.queryFixList()
    },
    //点击查看报修详情
    toFixDetails(repairId){
      this.$router.push({
        name: 'fixDetails',
        params: {
          repairId: repairId
        }
      })
    },
    //图片默认显示
    showDefault(index){
      // this.repairInfo[index].pics[0] = this.defaultShow;
      this.$set(this.repairInfo[index].pics,0,this.defaultShow)
    },
    //点击完成维修触发
    async toComplete(idx){
      try{
        await finishRepair( this.repairInfo[idx].repairId, this.userId)
      }
      catch(e){
        alert('异步请求异常')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.vux-tab .vux-tab-item.vux-tab-selected{
  color: #CE715E;
  border-bottom: 3px solid #CE715E;
}
.main-page /deep/ .vux-tab-bar-inner {
  background-color: #CE715E;
}
.main-page{
  background-color: #f9f9f9;
  width: 100%;
  height: 100%;
}
.tab{
  top: 46px;
}
.mlist{
  position: absolute;
  top: 91px;
  left: 0;
  width: 100%;
  height: calc(100% - 91px - 70px);
  overflow: auto;
  .vux-divider{
    margin: 5px 0 0 0 ;
    color: #ccc;
    font-size: 12px;
  }
}
.mbutton{
  position: absolute;
  bottom: 0;
  margin: 15px;
  width: calc(100% - 30px);
  height: 40px;
  background-color: #CE715E;
  border-radius: 21px;
  font-size:14px;
  font-family:PingFangSC-Medium;
  font-weight:500;
  color:rgba(255,255,255,1);
  text-align: center;
  line-height: 40px;
}
.mlist-cell{
  width: calc(100% - 30px);
  height: auto;
  background:rgba(255,255,255,1);
  border-radius:4px;
  margin: 15px 15px 0px 15px;
}
.list-top{
  width: calc(100% - 30px);
  height: 14px;
  padding: 15px;
}
.list-top-icon{
  float: left;
  height: 14px;
  width: 25px;
  line-height: 14px;
}
.list-top-img{
  width: 14px;
  height: 14px;
}
.list-top-number{
  height: 14px;
  width: calc(100% - 25px - 56px);
  float: left;
  overflow:hidden;
  font-size:14px;
  font-family:PingFang-SC-Regular;
  font-weight:400;
  color:rgba(51,51,51,1);
  line-height: 14px;
}
.list-top-status{
  width: 56px;
  height: 14px;
  float: right;
  overflow:hidden;
  text-align: right;
  font-size:14px;
  font-family:PingFangSC-Medium;
  font-weight:500;
  color:rgba(206,113,94,1);
  line-height:14px;
}
.list-body{
  height: 90px;
  width: calc(100% - 30px);
  padding-left: 15px;
  padding-right: 15px;
  .list-body-img{
    float: left;
    width: 90px;
    height: 90px;
    object-fit: cover;
  }
  .list-body-center{
    float: left;
    height: 90px;
    width: calc(100% - 90px - 16px);
  }
  .list-body-title{
    width: 100px;
    height: 32px;
    border-radius:4px;
    border:1px solid rgba(102,102,102,1);
    margin-top: 10px;
    margin-left: 10px;
    line-height: 32px;
    text-align: center;
    font-size:15px;
    font-family:PingFangSC-Medium;
    font-weight:500;
    color:rgba(51,51,51,1);
  }
  .list-body-time{
    width: 140px;
    height: 13px;
    margin-top: 25px;
    margin-left: 10px;
    font-size:13px;
    font-family:PingFang-SC-Regular;
    font-weight:400;
    color:rgba(153,153,153,1);
    line-height:13px;
  }
  .list-body-icon{
    float: right;
    width: 16px;
    height: 16px;
    padding-top: 37px;
  }
}
.list-bottom{
  height: 38px;
  width: 100%;
  .list-bottom-phone{
    float: right;
    padding-top: 9px;
    padding-right: 15px;
    width: 60px;
    height: 15px;
    font-size:15px;
    font-family:PingFangSC-Medium;
    font-weight:500;
    color:rgba(94,165,102,1);
    line-height:15px;
  }
}
.list-evaluation{
  height: 50px;
  width: 100%;
  border-top: 1px solid #F9F9F9;
  .evaluation-button{
    height: 32px;
    width: 73px;
    background:rgba(206,113,94,1);
    border-radius:4px;
    text-align: center;
    line-height: 32px;
    float: right;
    margin-right: 15px;
    margin-top: 9px;
    font-size:14px;
    font-family:PingFangSC-Medium;
    font-weight:500;
    color:rgba(255,255,255,1);
  }
}
</style>
