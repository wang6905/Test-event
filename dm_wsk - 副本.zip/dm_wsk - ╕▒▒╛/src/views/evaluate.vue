<template>
  <div>
    <div id="evaluate-contain">
      <dm-header :dm-title="title"></dm-header>
      <div class="start-evaluate">
        <span class="start-t tit">1.星级评价</span>
        <div class="rater-contain">
          <rater v-model="startNum" :margin="20" active-color="#F5BB5A" :font-size="22"></rater>
          <span class="score">{{startNum}}分</span>
        </div>
      </div>
      <div class="eva-describe">
        <div class="desc-t tit">2.评分描述</div>
        <textarea class="desc-input" v-model="describeContent" placeholder="留下你的补充~"/>
      </div>
      <div class="comfirm-btn" @click="comfirmEvaluate()">提交</div>
    </div>
  </div>
</template>

<script>
import { Rater,XInput } from 'vux'
import dmHeader from '@/components/header.vue'
import { postEvaluate } from '../utils/requestData'

export default {
  data(){
    return {
        title: '评价',
        startNum: 0,  //星级评价
        describeContent: '',  //评分描述
        repairId: ''
      }
    },
    components: {
      'dm-header':dmHeader,
      Rater,
      XInput,
    },
    methods:{
      //提交评价数据
      async comfirmEvaluate(){
        let fhRepairInfo = {
          repairId: this.repairId,
          accessClass: this.startNum,
          accessDecription: this.describeContent
        }
        let res = await postEvaluate(
          this.$route.params.userId,
          this.$route.params.username,
          fhRepairInfo
        )
        if(res.data.errCode == 'F'){
          var tip = '提交失败，'
        }else if (res.data.errCode == 'S') {
          var tip = '提交'
        }
        this.$vux.toast.show({
         text: tip + res.data.errMsg,
         time: 1000,
         type: 'text'
        })
        setTimeout(()=>{
          this.$router.push('/mainPage')
        },800)
      },
  },
  mounted(){
    this.repairId = this.$route.params.repairId;
  }
}
</script>

<style lang="scss" scoped>
#evaluate-contain{
  width: 100%;
  height: 100%;
  background-color: #F9F9F9;
  position: absolute;
  top: 0;
  left: 0;
  .go-icon{
    position: absolute;
    top: 10px;
    left: 16px;
    color: #333;
  }
  .evaluate-head{
    width: 100%;
    height: 46px;
    line-height: 46px;
    background-color: #fff;
    text-align: center;
    color: #333;
    font-size: 18px;
    font-family:PingFangSC-Medium;
    font-weight:600;
    border-bottom: 1px solid #f3f3f3;
  }
  .tit{
    color: #333333;
    font-size: 14px;
    font-family:PingFangSC-Medium;
    font-weight:500;
  }
  .start-evaluate{
    background-color: #fff;
    border-bottom: 1px solid #f3f3f3;
    margin-top: 47px;
    .start-t{
      margin-top: 15px;
      margin-left: 15px;
      display: inline-block;
    }
    .rater-contain{
      width: calc(100% - 15px);
      padding: 13px 0 16px 15px;
      position: relative;
      .score{
        position: absolute;
        font-family:PingFangSC-Medium;
        font-size: 14px;
        right: 15px;
        top: 16px;
      }
    }
  }
  .eva-describe{
    background-color: #fff;
    text-align: center;
    .desc-t{
      text-align: left;
      width: 100%;
      height: 40px;
      line-height: 40px;
      text-indent: 15px;
    }
    .desc-input{
      width: calc(100%  - 40px);
      height: calc(120px - 10px);
      border: 0;
      background-color: #FAFAFA;
      padding: 0;
      margin: 0 auto 15px auto;
      padding: 10px 0 0 10px;
      font-size:14px;
      font-family:PingFang-SC-Regular;
      &::-webkit-input-placeholder,&::-moz-placeholder,&::-ms-input-placeholder{
        font-size:14px;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color: #CCCCCC;
      }
      &:focus{
        outline: 0;
      }
    }
  }
  .comfirm-btn{
    width: calc(100% - 30px);
    height: 40px;
    line-height: 40px;
    border-radius: 21px;
    background-color: #CE715E;
    color: #fff;
    text-align: center;
    font-size:14px;
    font-family:PingFangSC-Medium;
    font-weight:500;
    position: absolute;
    bottom: 49px;
    left: 50%;
    transform: translate(-50%,0);
  }
}

</style>
