<template>
  <div class="addFix">
    <dm-header :dm-title="title"></dm-header>
    <group label-width="5em">
      <popup-picker title="故障类型" :data="breakdownList"  v-model="breakdown" :placeholder="placeholder1" @on-show="onShowBreakDownList()" show-name></popup-picker>
      <popup-picker title="联系人" :data="contectPersonList" v-model="selectPerson" :placeholder="placeholder2" @on-show="onShowConPersonList()"></popup-picker>
      <datetime :title="title3" :placeholder="placeholder3" v-model="serviceTime"></datetime>
    </group>
    <div class="af-tip">
      非必选项：有助于更快更好地解决您的问题
    </div>
    <div class="af-photo">
      <div class="photo-top">
        <span class="photo-top-txt">现场图片</span>
        <img class="photo-icon" src="../assets/camera.svg" @click="selectPop()">
      </div>
      <div class="photo-img">
        <div class="photo-img-cell" v-for="(pic,index) in photoArray">
          <img class="ctrl-img" :src="pic">
          <img class="cell-icon" src="../assets/x-circle.svg" @click="removePic(index)">
          <!--<img class="cell-icon" src="../assets/cance.svg">-->
        </div>
      </div>
      <div class="photo-remark">
        <textarea placeholder="故障描述(0~200字)" v-model="breakdownDescription"> </textarea>
      </div>
      <div class="af-submit" @click="submitFixInfo()">提交</div>
      <!--<toast v-model="showToast" :time="2000">{{toastMsg}}</toast>-->
    </div>
  </div>
</template>

<script>
  import {getLookupType, addRepair,queryDomitoryInfo} from '../utils/requestData'
import {PopupPicker, Group, Datetime, Toast} from 'vux'
import dmHeader from '@/components/header.vue'
import wpt from '../utils/wpt'
export default {
  data(){
    return{
      title: '报修',
      userId:'', // 用户编号
      userName:'',  // 用户名称
      breakdownList: [],  //故障类型选项数组,数据字典
      breakdown: [], //故障类型值,
      placeholder1: '请选择故障类型',
      placeholder2: '请选择联系人',
      placeholder3: '请选择时间',
      title3: '期望服务时间',
      value2: [],
      serviceTime:'', // '期望服务时间
      contectPersonList:[],  // 联系人列表
      selectPerson:[],  // 选择的联系人
      breakdownDescription:"",   // 报修描述
      photoArray:[]  // 图片路径数组
    }
  },
  components:{
    'dm-header': dmHeader,
    PopupPicker,
    Group,
    Datetime,
    Toast
  },
  methods:{
    async onShowBreakDownList(){
      // debugger
      let res = await getLookupType('BREAKDOWN_TYPE')
      let listCode = []
      res.data.lookUpCodes.forEach(function(r){
        listCode.push({
          name: r.lookupName,
          value: r.lookupCodeId.toString()
        })
      })
      this.breakdownList.splice(0,1,listCode)
      console.log("this.breakdownList",this.breakdownList)
    },
    showToast(msg,t){
      this.$vux.toast.show({
        text: msg,
        time: 2000,
        type: t,
        width:'160px'
      })
    },
    async submitFixInfo(){
      var self = this;
      var filePicture = [];
      if (this.breakdown.length <= 0){
        this.showToast('请选择故障类型','text');
        return;
      }else if (this.selectPerson.length <= 0) {
        this.showToast('请选择联系人','text');
        return;
      }else if(this.serviceTime.length <= 0){
        this.showToast('请选择时间','text')
        return;
      }else if(this.photoArray.length <= 0){
        this.showToast('请上传图片','text')
        return;
      }
      this.$vux.loading.show();
      let fhRepairInfo = {
        breakdownCode: this.breakdown[0],
        contactName: this.selectPerson[0],
        serviceTime: this.serviceTime,
        breakdownDescription: this.breakdownDescription
      }
      // console.log(this.serviceTime)
      // 上传文件
      wpt.uploadFile(async function (rst) {
        for (let i = 0;i < rst.length;i++){
          filePicture.push(rst[i].serverPath);
        }
        let res = await addRepair(
          self.userId,
          self.userName,
          fhRepairInfo,
          filePicture
        )
        self.$vux.loading.hide();
        if (res.data.errCode == 'S'){
          self.showToast('提交成功','success');
        }else {
          self.showToast(res.data.errMsg,'cancel');
        }
      },function (err) {
        alert('errMsg:'+ err);
        return;
      },{filePaths: self.photoArray, callProgress: "uploadProgress"});

      setTimeout( () => {
        this.$router.replace('/mainPage');
      },1.5e3)
    },
    async onShowConPersonList(){
      let res = await queryDomitoryInfo(this.userId);
      let tempArr = [];
      res.data.dormInfo.forEach((d)=>{
        tempArr.push(
          d.dormitoryManager
        )
      })
      this.contectPersonList.splice(0,1,tempArr);
    },
    //* 从相册选择图片
    takePic(){
      var self = this;
      wpt.selectPhoto({
        "isCompression": true
      },function (result) {
        self.photoArray.push(result.images[0]);
      },function (err) {
        alert(err);
      })
    },
    //* 拍照
    takeCamera(){
      var self = this;
      wpt.selectCamera({
        'isCompression':true
      },function (r) {
        self.photoArray.push(r.images[0]);
      },function (e) {
        alert(e);
      })
    },
    removePic(index){
      this.photoArray.splice(index,1);
    },
    // 选择添加图片
    selectPop(){
      if (this.photoArray.length >= 5) {
        this.showToast('最多只能添加5张图片','text');
        return;
      }
      var params = {
        "cancelButtonTitle": "取消", //返回0
        "items": ["拍照", "相册"]
      };
      var self = this;
      wpt.showSheet(params,function (r) {
        // console.log(r);
        if (r == '1' || r == 1 || r.index == '1'){
          self.takeCamera();
        }else if (r == '2'|| r == 2 || r.index == '2'){
          self.takePic();
        }
      },function (e) {
        alert(e);
      })
    }
  },
  mounted(){
    this.userId = this.$route.params.userId;
    this.userName = this.$route.params.userName;
  }
}
</script>

<style lang="scss" scoped>
.addFix{
  height: 100%;
  width: 100%;
  background-color: #f9f9f9;
  overflow: hidden;
}
.af-tip{
  height: 34px;
  width: calc(100% - 15px);
  background-color: #f9f9f9;
  font-size:14px;
  font-family:PingFang-SC-Regular;
  font-weight:400;
  color:rgba(102,102,102,1);
  padding-left: 15px;
  line-height: 34px;
  margin-top: 46px;
}
.af-photo{
  width: 100%;
  height: auto;
}
.photo-top{
  width: 100%;
  height: 44px;
  background-color: #ffffff;
}
.photo-top-txt{
  font-size:14px;
  font-family:PingFang-SC-Regular;
  font-weight:400;
  color:rgba(51,51,51,1);
  float: left;
  padding-top: 15px;
  padding-left: 15px;
  line-height:14px;
}
.photo-icon{
  float: right;
  padding-right: 15px;
  padding-top: 15px;
}
.photo-img{
  height: auto;
  width: calc(100% - 30px);
  background-color: #ffffff;
  overflow: auto;
  padding: 0px 15px 0px 15px;
}
.photo-img-cell{
  float: left;
  height: 60px;
  width: 60px;
  margin: 0px 10px 10px 0px;
}
.ctrl-img{
  float: left;
  height: 60px;
  width: 60px;
  border-radius: 4px;
}
.cell-icon{
  width: 17px;
  float: left;
  left: 60px;
  opacity: 0.7;
  position: relative;
  top: -61px;
  left: 44px;
}
.photo-remark{
  height: 100px;
  width: calc(100% - 30px);
  background-color: #ffffff;
  padding: 0px 15px 15px 15px;
}
.photo-remark textarea{
  outline: none;
  width: 100%;
  height: 100px;
  margin: 0;
  padding: 0;
  resize: none;
  border: 0;
  margin-top: 10px;
  font-family:PingFang-SC-Regular;
  /*background-color: #FAFAFA;*/
  &::-webkit-input-placeholder{
    color: #ccc;
  }
}
.af-submit{
  height: 40px;
  width: calc(100% - 30px);
  margin: 15px;
  background-color: #CE715E;
  position: fixed;
  bottom: 0;
  border-radius:21px;
  font-size:14px;
  font-family:PingFangSC-Medium;
  font-weight:500;
  color:rgba(255,255,255,1);
  line-height: 40px;
  text-align: center;
}
.addFix /deep/ .weui-cells{
  top: 46px;
}
.addFix /deep/ .weui-cells{
  margin-top: 0;
}
.addFix /deep/ .vux-no-group-title{
  margin-top: 0;
}
.addFix /deep/ .weui-label{
  font-size:14px;
  font-family:PingFang-SC-Regular;
  font-weight:400;
  color:rgba(102,102,102,1);
}
.addFix /deep/ .vux-datetime>div:first-child p{
  font-size:14px;
  font-family:PingFang-SC-Regular;
  font-weight:400;
  color:rgba(102,102,102,1);
  white-space: nowrap;
}
.addFix /deep/ .vux-popup-picker-select{
  text-align: left!important;
  font-size:14px;
  font-family:PingFang-SC-Regular;
  font-weight:400;
  color:rgba(204,204,204,1)!important;
  padding-left: 34px;
}
.addFix /deep/ .vux-datetime-value{
  padding-left: 34px;
  text-align: left!important;
  font-size:14px;
  font-family:PingFang-SC-Regular;
  font-weight:400;
  color:rgba(204,204,204,1)!important;
}
.addFix /deep/ .vux-datetime{
  height: 19px;
}
</style>
