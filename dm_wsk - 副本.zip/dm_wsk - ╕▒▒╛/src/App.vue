<template>
  <div id="app">
    <transition :name="transitionName">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      transitionName: 'router-pop-in'
    }
  },
  watch: {
    $route () {
      const isBack = this.$router.isBack || false
      if (isBack) {
        this.transitionName = 'router-pop-out'
      } else {
        this.transitionName = 'router-pop-in'
      }
      this.$router.isBack = false
    }
  }
}
</script>

<style lang="less">
html, body, #app {
  height: 100%;
  width: 100%;
  padding: 0;
  margin: 0;
  background-color: #fff;
}
.router-pop-out-enter-active,
.router-pop-out-leave-active,
.router-pop-in-enter-active,
.router-pop-in-leave-active {
  will-change: transform;
  transition: all 500ms;
  height: 100%;
  width: 100%;
  top: 0;
  position: absolute;
  backface-visibility: hidden;
  perspective: 1000;
}
.router-pop-out-enter {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}
.router-pop-out-leave-active {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.router-pop-in-enter {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.router-pop-in-leave-active {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}

#app {
  .page-container {
    height: 100%;
    display: flex;
    flex-direction: column
  }
  .v-content {
    flex: 1;
    overflow-x: hidden;
    overflow-y: scroll;
    -webkit-overflow-scrolling: touch;
  }
}

@keyframes zoomIn {
  0% { opacity: 0; transform: scale3d(.3, .3, .3) }
  50% { opacity: 1 }
}
.zoomIn {
  animation-name: zoomIn
}
.fade-enter-active,
.fade-leave-active {
  transition: all .5s;
}
.fade-enter,
.fade-leave-to{
  transition: all .5s;
}
</style>
