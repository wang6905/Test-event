import { axs } from './axios'
const urlHead = 'http://appstest.china-fuhai.com:10000/vapp/'   // 开发环境域名，富海移动

// 获取故障类型数据字典
export const getLookupType = (LookupType) => axs(
  urlHead + 'com.fh.baoxiu.mobileApi.queryDictByType.biz.ext',
  {
    lookUpType: LookupType
  }
)

// 新增单据接口
export const addRepair = (userId, username, fhRepairInfo, filePicture) => axs(
  urlHead + 'com.fh.baoxiu.mobileApi.addRepair.biz.ext',
  {
    userId: userId,
    username: username,
    fhRepairInfo: fhRepairInfo,
    filePicture: filePicture
  }
)

// 查询单据列表
export const queryRepairList = (pageIndex, pageSize, status, userId) => axs(
  urlHead + 'com.fh.baoxiu.mobileApi.queryRepairByStatusOrDate.biz.ext',
  {
    pageIndex: pageIndex,
    pageSize: pageSize,
    status: status,
    userId: userId
  }
)

// 单据评价接口
export const postEvaluate = (userId, username, fhRepairInfo) => axs(
  urlHead + 'com.fh.baoxiu.mobileApi.evaluate.biz.ext',
  {
    userId: userId,
    username: username,
    fhRepairInfo: fhRepairInfo
  }
)

// 查询单据详情
export const queryRepairDetail = (repairId) => axs(
  urlHead + 'com.fh.baoxiu.mobileApi.queryRepairDetailByRid.biz.ext', {
    repairId: repairId
  }
)

//查询联系人 宿舍管理员
export const queryDomitoryInfo = (userId) => axs(
  urlHead + 'com.fh.baoxiu.mobileApi.queryDomitoryInfo.biz.ext',{
    userId: userId
  }
)

//完成维修功能接口，点击完成维修按钮触发该请求
export const finishRepair = ( repairId, userId ) => axs(
  urlHead + 'com.fh.baoxiu.mobileApi.finishRepair.biz.ext',
  {
    repairId: repairId,
    userId: userId
  }
)
