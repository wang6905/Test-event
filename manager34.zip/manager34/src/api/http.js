// 导入axios
import axios from 'axios'
// 导入路由
import router from '../router/router'
// 弹框
import Vue from 'vue'

// 创建副本
const managerAxios = axios.create({
  // 基地址
  baseURL: 'http://localhost:8888/api/private/v1/'
})

// 添加axios拦截器 拦截请求和响应

// 添加请求拦截器
managerAxios.interceptors.request.use(
  function(config) {
    // 请求成功触发
    console.log('请求成功')
    // 添加请求头
    // 添加token
    config.headers.Authorization = window.sessionStorage.getItem('token')
    return config
  },
  function(error) {
    // 请求失败触发
    return Promise.reject(error)
  }
)

// 添加响应拦截器
managerAxios.interceptors.response.use(
  function(response) {
    // 响应成功触发
    console.log('响应成功')
    // console.log(response)
    if (
      response.data.meta.status == 400 &&
      response.data.meta.msg == '无效token'
    ) {
      // 伪造的token 坏人
      // 删掉他
      window.sessionStorage.clear()
      // 打回去
      router.push('/login')
      // 弹框
      new Vue().$message.error('小样，伪造token，滚犊子！！！！')
    }
    return response
  },
  function(error) {
    // 响应失败触发
    return Promise.reject(error)
  }
)

// 暴露接口方法 -登录
export const login = ({ username, password }) => {
  return managerAxios.post('/login', {
    username,
    password
  })
}

// 暴露接口方法 - 获取用户列表
export const users = ({ query, pagenum, pagesize }) => {
  return managerAxios.get('users', {
    // get的参数必须通过这种方式来设置
    params: {
      query,
      pagenum,
      pagesize
    }
    // 设置请求头 迁移到了 axios的请求拦截器
    // headers: {
    //   Authorization: window.sessionStorage.getItem('token')
    // }
  })
}

// 暴露接口方法 - 获取左侧菜单
export const menus = () => {
  return managerAxios.get('/menus', {
    // 设置请求头
    // headers: {
    //   Authorization: window.sessionStorage.getItem('token')
    // }
  })
}

// 接口方法 - 获取权限列表 list的形式
// /:type  意思是 type这个位置传参用的
export const rightList = () => {
  return managerAxios.get('/rights/list')
}
// 接口方法 - 添加用户
export const addUser = ({ username, password, email, mobile }) => {
  return managerAxios.post('/users', {
    username,
    password,
    email,
    mobile
  })
}

// 接口方法 - 删除用户
export const deleteUser = ({ id }) => {
  return managerAxios.delete(`/users/${id}`)
}
// 接口方法 - 修改用户状态
export const updateUserState = ({ id, type }) => {
  return managerAxios.put(`/users/${id}/state/${type}`)
}
// 接口方法 - 修改用户信息 数据的提交和post类似
export const updateUserInfo = ({ id, email, mobile }) => {
  return managerAxios.put(`/users/${id}`, {
    email,
    mobile
  })
}

// 接口方法 - 角色列表获取
export const roles = () => {
  return managerAxios.get('/roles')
}
// 接口方法 - 分配用户角色
export const disRoles = ({ id, rid }) => {
  return managerAxios.put(`/users/${id}/role`, {
    rid
  })
}

// 接口方法 - 删除角色的指定权限
export const delRoleRight = ({ roleId, rightId }) => {
  return managerAxios.delete(`roles/${roleId}/rights/${rightId}`)
}

// 接口方法 - 获取所有权限，树形结构
export const rightsTree = () => {
  return managerAxios.get('rights/tree')
}
// 接口方法 - 角色授权
export const giveRoleRights = ({ roleId, rids }) => {
  return managerAxios.post(`roles/${roleId}/rights`, {
    rids
  })
}

// 获取商品数据列表
export const getCategories = () => {
  return managerAxios.get('/categories', {
    params: {
      type: 3
    }
  })
}
// 获取数据报表
export const getReports = () => {
  return managerAxios.get('/reports/type/1')
}
