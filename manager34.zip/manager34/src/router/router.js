// 导入Vue
import Vue from 'vue'

// 路由相关部分
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// 组件
import login from '../views/login.vue'
import index from '../views/index.vue'
import error from '../views/error.vue'

// 嵌套路由
import users from '../views/users.vue'
import roles from '../views/roles.vue'
import rights from '../views/rights.vue'
import categories from '../views/categories.vue'
import orders from '../views/orders.vue'
import reports from '../views/reports.vue'
import params from '../views/params.vue'

// 商品 goods的路由 
import goods from '../views/goods/goods.vue'

// goods的嵌套路由
import goodsIndex from '../views/goods/components/goodsIndex.vue'
import goodsAdd from '../views/goods/components/goodsAdd.vue'

// 规则
const routes = [
  {
    path: '/login',
    component: login,
    // 路由元信息
    meta: {
      needLogin: false
    }
  },
  {
    path: '/index',
    component: index,
    children: [
      {
        path: 'users', //index/users
        component: users
      },
      {
        path: 'roles', //index/roles
        component: roles
      },
      {
        path: 'rights', //index/rights
        component: rights
      },
      {
        path: 'goods', //index/goods
        component: goods,
        // 嵌套路由
        children:[
          {
            // 嵌套路由不用加/
            path:'', // /index/goods
            component:goodsIndex
          },
          {
            // 嵌套路由不用加/
            path:'add', // /index/goods/add
            component:goodsAdd
          }
        ]
      },
      {
        path: 'categories', //index/categories
        component: categories
      },
      {
        path: 'orders', //index/orders
        component: orders
      },
      {
        path: 'reports', //index/reports
        component: reports
      },
      {
        path: 'params', //index/params
        component: params
      }
    ]
  },
  // 错误页
  {
    path: '/error',
    component: error
  },
  // 兜底的规则
  {
    path: '*',
    redirect: '/error'
  }
]

// 实例化路由
const router = new VueRouter({
  routes
})

// 增加导航守卫
router.beforeEach((to, from, next) => {
  console.log(to)
  // 找到需要判断的页面
  // if (to.path.indexOf('/index') == 0) {
  if (to.meta.needLogin == false) {
    // 地址是 /login
    // 请求的是 登录页 不需要登录判断 直接放过去
    next()
  } else {
    // 登录状态判断
    if (window.sessionStorage.getItem('token') != undefined) {
      // 去吧
      next()
    } else {
      // 弹框
      new Vue().$message.error('哥们，先登录！滑稽')
      // 去登录页
      router.push('/login')
    }
  }
})

// 暴露出去
export default router
