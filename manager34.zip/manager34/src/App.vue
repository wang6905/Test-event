<template>
  <!-- 出口 -->
  <router-view></router-view>
</template>

<script>
export default {
  name: "app"
};
</script>

<style>
</style>
