<template>
  <el-breadcrumb class="my-breadcrumb" separator-class="el-icon-arrow-right">
    <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
    <el-breadcrumb-item>{{nav1}}</el-breadcrumb-item>
    <el-breadcrumb-item>{{nav2}}</el-breadcrumb-item>
  </el-breadcrumb>
</template>

<script>
export default {
  name: "mybread",
  // 定义允许外部传入的参数 function mybread(nav1,nav2)
  props: ["nav1", "nav2"],
  created() {
    console.log(this.nav1);
    console.log(this.nav2);
  }
};
</script>

<style lang="less" scoped>
.my-breadcrumb {
  height: 45px;
  line-height: 45px;
}
</style>
