import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

// 整合饿了么ui
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)

// 全局导入样式
import './assets/base.css'

// 导入自己抽取的router js可以不写
import router from './router/router'

// 注册面包屑组件
import mybread from './components/mybread.vue'
Vue.component('mybread', mybread)

new Vue({
  render: h => h(App),
  // 挂在到Vue实例上
  router
}).$mount('#app')
