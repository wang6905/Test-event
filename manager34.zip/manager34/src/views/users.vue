<template>
  <div>
    <!-- 面包屑  mybread(用户管理，用户列表) -->
    <mybread nav1="用户管理" nav2="用户列表"></mybread>
    <!-- 文本框 +按钮 +栅格-->
    <el-col>
      <el-col :span="4">
        <!-- 输入框 文本框 -->
        <el-input
          placeholder="请输入内容"
          v-model.trim="query"
          @keyup.enter.native="search"
          class="input-with-select"
        >
          <el-button slot="append" @click="search" icon="el-icon-search"></el-button>
        </el-input>
      </el-col>
      <el-col :span="2">
        <el-button type="success" @click="dialogFormVisible=true" plain>添加用户</el-button>
      </el-col>
    </el-col>

    <!-- table -->

    <el-table :data="tableData" style="width: 100%" border>
      <!-- 索引 -->
      <el-table-column type="index"></el-table-column>
      <el-table-column prop="username" label="姓名" width="180"></el-table-column>
      <el-table-column prop="email" label="邮箱" width="180"></el-table-column>
      <el-table-column prop="mobile" label="电话"></el-table-column>
      <el-table-column label="用户状态">
        <template slot-scope="scope">
          <!-- 开关 -->
          <el-switch
            v-model="scope.row.mg_state"
            @change="changeState(scope.row)"
            active-color="#13ce66"
            inactive-color="#ff4949"
          ></el-switch>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <!-- 编辑按钮 -->
          <el-button
            type="primary"
            icon="el-icon-edit"
            @click="enterEdit(scope.row)"
            plain
            size="mini"
          ></el-button>
          <!-- 删除按钮 把这一行的数据都给你 -->
          <el-button
            type="danger"
            icon="el-icon-delete"
            @click="delOne(scope.row)"
            plain
            size="mini"
          ></el-button>
          <!-- 点击分配角色 -->
          <el-button
            type="warning"
            @click="showRole(scope.row)"
            icon="el-icon-check"
            plain
            size="mini"
          ></el-button>
        </template>
      </el-table-column>
      <!-- 测试用 组件内部 传入的结构 无法访问到 自己data中的数据 需要通过 作用域插槽 slot-scope 为数据起别名 才可以获取到值 -->
      <!-- <el-table-column>
        <el-switch v-model="value" active-color="#13ce66" inactive-color="#ff4949"></el-switch>
      </el-table-column>-->
    </el-table>
    <!-- 分页 -->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pagenum"
      :page-sizes="[5, 10, 15, 16]"
      :page-size="pagesize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
    ></el-pagination>

    <!-- 对话框 新增框 -->
    <el-dialog title="添加用户" :visible.sync="dialogFormVisible">
      <!--ref的一会可以获取到  -->
      <el-form ref="ruleForm" :rules="rules" :model="form" label-position="top">
        <el-form-item label="用户名" prop="username" label-width="120px">
          <el-input v-model="form.username" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password" label-width="120px">
          <el-input v-model="form.password" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" label-width="120px">
          <el-input v-model="form.email" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="电话" label-width="120px">
          <el-input v-model="form.mobile" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitForm('ruleForm')">确 定</el-button>
      </div>
    </el-dialog>

    <!-- // 修改框 -->
    <el-dialog title="修改用户" :visible.sync="editFormVisible">
      <!--ref的一会可以获取到  -->
      <el-form ref="ruleForm" :rules="rules" :model="editForm" label-position="top">
        <el-form-item label="用户名" prop="username" label-width="120px">
          <el-input v-model="editForm.username" disabled autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" label-width="120px">
          <el-input v-model="editForm.email" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="电话" label-width="120px">
          <el-input v-model="editForm.mobile" autocomplete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="editFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveEdit">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 分配角色弹框 -->
    <el-dialog title="分配角色" :visible.sync="roleFormVisible">
      <el-form :model="roleForm">
        <el-form-item label="当前用户" label-width="120px">{{roleForm.userName}}</el-form-item>
        <el-form-item label="请选择角色" label-width="120px">
          <el-select v-model="roleForm.role" placeholder="请选择活动区域">
            <el-option v-for="item in roleList" :label="item.roleName" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="roleFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="disRoles">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 测试用switch -->
    <!-- <el-switch v-model="value" active-color="#13ce66" inactive-color="#ff4949"></el-switch> -->
  </div>
</template>

<script>
// 导入接口 导入多个值 在同一个文件中
import {
  users,
  addUser,
  deleteUser,
  updateUserState,
  updateUserInfo,
  roles,
  disRoles
} from "../api/http";
export default {
  name: "users",
  // 数据
  data() {
    return {
      // 角色列表数据
      roleList: [],
      // 分配用户弹框 标记
      roleFormVisible: false,
      // 分配用户弹框的 数据
      roleForm: {
        role: "",
        // 当前编辑的用户名
        userName: "",
        // 当前正在编辑的用户id
        id: 0
      },
      // switch绑定的数据
      value: false,
      tableData: [
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1517 弄"
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1519 弄"
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄"
        }
      ],
      // 提交的数据
      // 页码
      pagenum: 1,
      // 页容量
      pagesize: 5,
      // 搜索
      query: "",
      // 弹框的标记字段
      dialogFormVisible: false,
      // 表单的数据
      form: {
        username: "",
        password: "",
        email: "",
        mobile: ""
      },
      // 表单验证规则
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { min: 3, max: 12, message: "长度在 3 到 12 个字符", trigger: "blur" }
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 6, max: 12, message: "长度在 6 到 12 个字符", trigger: "blur" }
        ]
      },
      // 编辑框是否弹出
      editFormVisible: false,
      // 编辑框对应的数据
      editForm: {
        username: "",
        mobile: "",
        email: "",
        // 用户id 方便一会编辑
        id: ""
      },
      // 总页数
      total: 0
    };
  },
  created() {
    // 获取用户数据
    this.search();
  },
  // 方法
  methods: {
    // 分配权限
    disRoles() {
      // 如果是串 啥事都不干 
      if(typeof (this.roleForm.role)=='string'){
        // 关闭弹框
        this.roleFormVisible = false
        return 
      }
      // 角色已经分配
      disRoles({ id: this.roleForm.id, rid: this.roleForm.role }).then(
        backData => {
          // console.log(backData);
          if(backData.data.meta.status==200){
            // 成功了
            this.roleFormVisible = false
            // 提示用户
            this.$message.success('恭喜你，修改成功啦！')
            // 重新获取数据
            this.search()
          }
        }
      );
    },
    // 显示 权限弹框
    showRole(row) {
      // console.log(row);
      // 弹框
      this.roleFormVisible = true;
      // 用户名
      this.roleForm.userName = row.username;
      // 设置选中 关联
      this.roleForm.role = row.role_name;
      // 把用户id存起来 方便分配角色时使用
      this.roleForm.id = row.id;
      // 获取角色列表
      roles().then(backData => {
        // console.log(backData);
        // 保存数据
        if (backData.data.meta.status == 200) {
          this.roleList = backData.data.data;
        }
      });
    },
    // 保存修改
    saveEdit() {
      updateUserInfo(this.editForm).then(backData => {
        // console.log(backData);
        if (backData.data.meta.status == 200) {
          this.$message.success("小样，改好了哟！！！");
          // 关闭弹框
          this.editFormVisible = false;
          // 重新获取数据
          this.search();
        }
      });
    },
    // 进入编辑 row就是这一行的数据
    enterEdit(row) {
      // 弹框
      this.editFormVisible = true;
      // 设置给 editForm即可显示
      this.editForm = row;
    },

    // 修改状态
    changeState(row) {
      // console.log(row);
      updateUserState({
        id: row.id,
        type: row.mg_state
      }).then(backData => {
        // console.log(backData);
        if (backData.data.meta.status == 200) {
          this.search();
        }
      });
    },
    // 删除用户
    delOne(row) {
      // console.log(row);
      this.$confirm("此操作将永久删除该用户, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // 点击了确认
          deleteUser({
            id: row.id
          }).then(backData => {
            // console.log(backData);
            if (backData.data.meta.status == 200) {
              // 重新获取数据
              this.search();
              this.$message.success("删掉了，开心了吧！！");
            }
          });
        })
        .catch(() => {
          // 点击了取消
          this.$message("想清楚再点，小老弟！！！");
        });
    },
    // 搜索用户
    search() {
      users({
        query: this.query,
        pagesize: this.pagesize,
        pagenum: this.pagenum
      }).then(backData => {
        console.log(backData);
        // 判断
        if (backData.data.meta.status == 200) {
          // 赋值
          this.tableData = backData.data.data.users;
          // 保存总条数
          this.total = backData.data.data.total;
        }
      });
    },
    // 提交表单
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          // 对的
          addUser(this.form).then(backData => {
            // console.log(backData);
            if (backData.data.meta.status == 201) {
              // 关闭弹框
              this.dialogFormVisible = false;
              // 重新获取数据
              this.search();
            }
          });
        } else {
          // 弹框
          this.$message.warning("数据格式不对，请检查");
          return false;
        }
      });
    },
    edit(index, row) {
      console.log(index, row);
    },
    handleSizeChange(size) {
      // console.log('size:'+size)
      this.pagesize = size;
      // 重新获取数据
      this.search();
    },
    handleCurrentChange(current) {
      console.log("current:" + current);
      this.pagenum = current;
      // 重新获取数据
      this.search();
    }
  }
};
</script>

<style scoped lang="less">
</style>
