<template>
  <el-container class="my-container">
    <!-- 头部布局 -->
    <el-header class="my-header">
      <el-col>
        <el-col :span="4">
          <img class="logo" src="../assets/logo.jpg" alt />
        </el-col>
        <el-col :span="19">
          <h2 class="title">电竞后台管理系统</h2>
        </el-col>
        <el-col :span="1">
          <!-- 事件绑定阻止默认行为 -->
          <a class="logout" @click.prevent="logOut" href="#">退出</a>
        </el-col>
      </el-col>
    </el-header>
    <el-container>
      <!-- 侧边栏 用的是导航 -->
      <el-aside width="200px" class="my-asider">
        <el-menu
          default-active="2"
          class="el-menu-vertical-demo"
          :unique-opened="false"
          :router="true"
        >
          <!-- 导航1 -->
          <el-submenu v-for="(item,index) in menuList" :index="''+index">
            <template slot="title">
              <!-- 一级标题 -->
              <i class="el-icon-location"></i>
              <span>{{item.authName}}</span>
            </template>
            <!-- 内层循环 -->
            <el-menu-item v-for="(it,i) in item.children" :index="'/index/'+it.path">
              <i class="el-icon-menu"></i>
              {{it.authName}}
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-aside>
      <!-- 右侧内容 -->
      <el-main class="my-main">
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { menus } from "../api/http";

export default {
  name: "index",
  // 数据
  data() {
    return {
      // 菜单列表
      menuList: []
    };
  },
  // 获取初始数据
  created() {
    menus().then(backData => {
      console.log(backData);
      // 菜单数据设置
      this.menuList = backData.data.data;
    });
  },
  // 方法
  methods: {
    logOut() {
      // 提示用户
      this.$confirm("此操作，会立即退出该账号，你想明白了吗？滑稽1", "警告", {
        confirmButtonText: "确认",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // 对
          // 删除token
          window.sessionStorage.removeItem("token");
          // 去登录页
          this.$router.push("/login");
        })
        .catch(() => {
          // 啥都不做
          this.$message("你真好！");
        });
    }
  }
};
</script>

<style lang="less" scoped>
.my-container {
  height: 100%;
  .my-header {
    height: 60px;
    background-color: #b3c0d1;
    line-height: 60px;
    .logo {
      height: 60px;
    }
    .title {
      text-align: center;
      color: white;
    }
    .logout {
      color: white;
      text-decoration: none;
      background-color: hotpink;
      padding: 5px;
    }
  }
  .my-asider {
  }
  .my-main {
    background-color: #e9eef3;
    padding-top: 0px;
  }
}
</style>
