<template>
  <div>
    <!-- 面包屑  mybread(用户管理，用户列表) -->
    <mybread nav1="订单管理" nav2="订单列表"></mybread>

    <!-- table -->
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="date" label="日期" width="180"></el-table-column>
      <el-table-column prop="name" label="姓名" width="180"></el-table-column>
      <el-table-column prop="address" label="地址"></el-table-column>
      <el-table-column prop="address" label="操纵">
        <template>
          <!-- 编辑按钮 -->
          <el-button
            type="primary"
            icon="el-icon-edit"
            @click="dialogFormVisible=true"
            plain
            size="mini"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageindex"
      :page-sizes="[100, 200, 300, 400]"
      :page-size="100"
      layout="total, sizes, prev, pager, next, jumper"
      :total="400"
    ></el-pagination>
    <!-- 对话框 -->
    <el-dialog title="收货地址" :visible.sync="dialogFormVisible">
      <!-- 级联选择器 -->
      <el-cascader
        v-model="value"
        :options="options"
        :props="{ expandTrigger: 'hover' }"
        @change="handleChange"
      ></el-cascader>
      <!-- 使用插件实现省市联动 -->
      <VDistpicker></VDistpicker>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// 导入数据
import options from "../assets/city_data_2017";

import VDistpicker from "v-distpicker";
export default {
  name: "orders",
  // 组件注册
  components: {
    VDistpicker
  },
  // 数据
  data() {
    return {
      // 对话框的标记
      dialogFormVisible: false,
      // 级联选择器的双向绑定的数据
      value: [],
      // 级联选择器的数据
      options,
      tableData: [
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1517 弄"
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1519 弄"
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄"
        }
      ],
      // 当前页
      pageindex: 1,
      // 输入框绑定的数据
      input3: ""
    };
  },
  // 方法
  methods: {
    handleSizeChange(size) {},
    handleCurrentChange(current) {}
  }
};
</script>

<style scoped lang="less">
</style>
