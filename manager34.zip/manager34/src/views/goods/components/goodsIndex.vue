<template>
  <div>
    <!-- 文本框 +按钮 +栅格-->
    <el-col>
      <el-col :span="4">
        <!-- 输入框 文本框 -->
        <el-input placeholder="请输入内容" v-model="input3" class="input-with-select">
          <el-button slot="append" icon="el-icon-search"></el-button>
        </el-input>
      </el-col>
      <el-col :span="2">
        <el-button type="success" @click="toGoodsAdd" plain>添加商品</el-button>
      </el-col>
    </el-col>

    <!-- table -->
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="date" label="日期" width="180"></el-table-column>
      <el-table-column prop="name" label="姓名" width="180"></el-table-column>
      <el-table-column prop="address" label="地址"></el-table-column>
    </el-table>
    <!-- 分页 -->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageindex"
      :page-sizes="[100, 200, 300, 400]"
      :page-size="100"
      layout="total, sizes, prev, pager, next, jumper"
      :total="400"
    ></el-pagination>
  </div>
</template>

<script>
export default {
  name:'goodsIndex',
  // 数据
  data() {
    return {
      tableData: [
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1517 弄"
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1519 弄"
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1516 弄"
        }
      ],
      // 当前页
      pageindex: 1,
      // 输入框绑定的数据
      input3: ""
    };
  },
  // 方法
  methods: {
    // 去新增页
    toGoodsAdd(){
      this.$router.push("/index/goods/add")
    },
    handleSizeChange(size) {},
    handleCurrentChange(current) {}
  }
};
</script>

<style>
</style>
