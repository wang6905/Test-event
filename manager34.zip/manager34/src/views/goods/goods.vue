<template>
  <div>
    <!-- 面包屑  mybread(用户管理，用户列表) -->
    <mybread nav1="商品管理" nav2="商品列表"></mybread>
    <!-- 路由出口 -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "goods",

};
</script>

<style scoped lang="less">
</style>
