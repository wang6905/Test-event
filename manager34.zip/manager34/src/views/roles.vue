<template>
  <div>
    <!-- 面包屑  mybread(用户管理，用户列表) -->
    <mybread nav1="权限管理" nav2="角色列表"></mybread>
    <!-- 按钮 +栅格-->
    <el-col>
      <!-- 按钮 -->
      <el-col :span="2">
        <el-button plain>添加角色</el-button>
      </el-col>
    </el-col>

    <!-- table -->
    <el-table :data="tableData" style="width: 100%" border>
      <!-- 展开行 -->
      <el-table-column type="expand">
        <template slot-scope="props">
          <!-- 循环顶级的row -->
          <el-row v-for="topLevel in props.row.children">
            <el-col :span="4">
              <el-tag
                class="my-tag"
                closable
                type="primary"
                @close="delRight(props.row,topLevel)"
              >{{topLevel.authName}}</el-tag>
              <span class="el-icon-arrow-right"></span>
            </el-col>
            <!-- 右侧 -->
            <el-col :span="20">
              <!-- 二级level -->
              <el-row v-for="secondLevel in topLevel.children">
                <el-col :span="6">
                  <el-tag
                    class="my-tag"
                    closable
                    type="success"
                    @close="delRight(props.row,secondLevel)"
                  >{{secondLevel.authName}}</el-tag>
                  <span class="el-icon-arrow-right"></span>
                </el-col>
                <!-- 右侧 -->
                <!-- 三级level -->
                <el-col :span="18">
                  <el-tag
                    class="my-tag"
                    v-for="thirdLevel in secondLevel.children "
                    closable
                    type="warning"
                    @close="delRight(props.row,thirdLevel)"
                  >{{thirdLevel.authName}}</el-tag>
                </el-col>
              </el-row>
            </el-col>
          </el-row>
        </template>
      </el-table-column>
      <!-- 索引 -->
      <el-table-column type="index"></el-table-column>
      <el-table-column prop="roleName" label="角色名称" width="180"></el-table-column>
      <el-table-column prop="roleDesc" label="角色描述" width="180"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <!-- 编辑按钮 -->
          <el-button type="primary" icon="el-icon-edit" plain size="mini"></el-button>
          <!-- 删除按钮 把这一行的数据都给你 -->
          <el-button type="danger" icon="el-icon-delete" plain size="mini"></el-button>
          <!-- 点击分配角色 -->
          <el-button
            type="warning"
            icon="el-icon-check"
            @click="showDialog(scope.row)"
            plain
            size="mini"
          ></el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- tree -->
    <!-- <el-tree
      :data="data"
      show-checkbox
      node-key="id"
      default-expand-all
      :default-checked-keys="[5,1,4,9,10]"
      :props="defaultProps"
    ></el-tree>-->

    <!-- 分配权限弹框 -->
    <el-dialog title="权限分配" :visible.sync="dialogFormVisible">
      <el-tree
        :data="data"
        show-checkbox
        node-key="id"
        default-expand-all
        :default-checked-keys="checkedKeys"
        :props="defaultProps"
        ref="tree"
      ></el-tree>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="giveRights">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// 导入接口
import { roles, delRoleRight, rightsTree, giveRoleRights } from "../api/http";
export default {
  name: "roles",
  // 数据
  data() {
    return {
      // 当前正在编辑的角色
      editRole: {},
      // 弹框的标记字段
      dialogFormVisible: false,
      tableData: [],
      // 当前页
      pageindex: 1,
      // 输入框绑定的数据
      input3: "",
      data: [
        {
          id: 1,
          label: "一级 1",
          children: [
            {
              id: 4,
              label: "二级 1-1",
              children: [
                {
                  id: 9,
                  label: "三级 1-1-1"
                },
                {
                  id: 10,
                  label: "三级 1-1-2"
                }
              ]
            }
          ]
        },
        {
          id: 2,
          label: "一级 2",
          children: [
            {
              id: 5,
              label: "二级 2-1"
            },
            {
              id: 6,
              label: "二级 2-2"
            }
          ]
        },
        {
          id: 3,
          label: "一级 3",
          children: [
            {
              id: 7,
              label: "二级 3-1"
            },
            {
              id: 8,
              label: "二级 3-2"
            }
          ]
        }
      ],
      defaultProps: {
        children: "children",
        label: "authName"
      },
      // 树形菜单默认被选中的 key
      checkedKeys: []
    };
  },
  // 获取数据
  created() {
    this.getData();
    this.getTree();
  },
  // 方法
  methods: {
    // 授权
    giveRights() {
      // 获取选中的id
      // 把数组按照给定的字符进行拼接
      // const ridList = this.$refs.tree.getCheckedKeys()
      // // 获取半选中的节点
      // const halfList = this.$refs.tree.getHalfCheckedKeys()
      // // console.log(rids,halfRids)
      // const totalIds = [...ridList,...halfList]
      // const rids = totalIds.join(',')
      // 一行搞定
      const rids = [
        ...this.$refs.tree.getCheckedKeys(),
        ...this.$refs.tree.getHalfCheckedKeys()
      ].join(",");
      // console.log(rids)

      const roleId = this.editRole.id;
      // 提交数据
      giveRoleRights({ roleId, rids }).then(backData => {
        // console.log(backData);
        if (backData.data.meta.status == 200) {
          this.dialogFormVisible = false;
          this.$message.success("权限更新成功！！！！");
          // 重新渲染页面
          this.getData();
        }
      });
    },

    // 获取树形菜单数据的方法
    getTree() {
      // 获取树形权限数据
      rightsTree().then(backData => {
        // console.log(backData);
        if (backData.data.meta.status == 200) {
          this.data = backData.data.data;
        }
      });
    },
    // 弹出权限对话框
    showDialog(row) {
      // 获取树形菜单的数据
      this.getTree();
      // 设置保存选中状态的空数组
      let checkedKeys = [];
      // 计算选中的内容
      // for (let i = 0; i < row.children.length; i++) {
      //   // checkedKeys.push(row.children[i].id);
      //   // 二级
      //   let secondChildren = row.children[i].children;
      //   for (let i = 0; i < secondChildren.length; i++) {
      //     // checkedKeys.push(secondChildren[i].id);
      //     // 三级
      //     let thirdChildren = secondChildren[i].children;
      //     for (let i = 0; i < thirdChildren.length; i++) {
      //       checkedKeys.push(thirdChildren[i].id);
      //     }
      //   }
      // }

      // 递归的方式来实现 items 数据 有children 也有可能没有children
      function addCheckedKeys(items) {
        // 遍历
        for (let i = 0; i < items.children.length; i++) {
          // 还有儿子
          if (items.children[i].children) {
            addCheckedKeys(items.children[i]);
          } else {
            // 没有儿子
            checkedKeys.push(items.children[i].id);
          }
        }
      }

      // 调用
      addCheckedKeys(row);

      console.log(checkedKeys);
      // 赋值给选中的key
      this.checkedKeys = checkedKeys;
      // 弹框
      this.dialogFormVisible = true;
      // 保存正在编辑的角色
      this.editRole = row;
    },
    // 获取数据的方法
    getData() {
      roles().then(backData => {
        // console.log(backData)
        if (backData.data.meta.status == 200) {
          this.tableData = backData.data.data;
        }
      });
    },
    // 删除指定权限
    delRight(row, tag) {
      // console.log(row.id);
      // console.log(tag.id);
      delRoleRight({ roleId: row.id, rightId: tag.id }).then(backData => {
        console.log(backData);
        if (backData.data.meta.status == 200) {
          // this.getData();
          // 直接把服务器返回的这个角色的权限数据 赋值即可
          row.children = backData.data.data;
        }
      });
    }
  }
};
</script>

<style scoped lang="less">
.my-tag {
  margin-right: 10px;
  margin-bottom: 10px;
}
</style>
