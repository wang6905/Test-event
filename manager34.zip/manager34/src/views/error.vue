<template>
  <div class='error'>
    <img src="../assets/404.gif" alt="" @click="toLogin">
  </div>
</template>

<script>
export default {
  created() {
    this.$message.error('哥们，你的地址不太对哦，点击那个滑板去登录页')
  },
  methods: {
    toLogin(){
      this.$router.push('/login')
    }
  },
}
</script>

<style lang='less' scoped>
  .error{
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #7fbeed;
    img{}
  }
</style>
