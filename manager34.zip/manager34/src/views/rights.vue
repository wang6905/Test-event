<template>
  <div>
    <!-- 面包屑  -->
    <mybread nav1="权限管理" nav2="权限列表"></mybread>
    <!-- 按钮 +栅格-->
    <!-- table -->
    <el-table :data="tableData" style="width: 100%">
      <!-- 显示索引 -->
      <el-table-column type="index" width="50"></el-table-column>
      <el-table-column prop="authName" label="权限名称" width="180"></el-table-column>
      <el-table-column prop="path" label="路径" width="180"></el-table-column>
      <el-table-column prop="level" label="层级"></el-table-column>
    </el-table>
  </div>
</template>

<script>
// 导入接口方法
import { rightList } from "../api/http";
export default {
  name: "rights",
  // 数据
  data() {
    return {
      // table的数据
      tableData: [],
      // 当前页
      pageindex: 1,
      // 输入框绑定的数据
      input3: ""
    };
  },
  // 生命周期钩子
  created() {
    rightList().then(backData => {
      // console.log(backData)
      if (backData.data.meta.status == 200) {
        // 服务器返回的level不是我们要的内容 调整为自己的内容即可
        for (let i = 0; i < backData.data.data.length; i++) {
          switch (backData.data.data[i].level) {
            case "0":
              backData.data.data[i].level = "一级";
              break;
            case "1":
              backData.data.data[i].level = "二级";
              break;
            case "2":
              backData.data.data[i].level = "三级";
              break;
          }
          console.log("执行啦");
        }
        // 保存数据
        this.tableData = backData.data.data;
      }
    });
  },
  // 方法
  methods: {
    handleSizeChange(size) {},
    handleCurrentChange(current) {}
  }
};
</script>

<style scoped lang="less">
</style>
