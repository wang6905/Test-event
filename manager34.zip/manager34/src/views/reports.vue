<template>
  <div>
    <!-- 面包屑  mybread(用户管理，用户列表) -->
    <mybread nav1="数据统计" nav2="数据报表"></mybread>
    <!-- 画图的地方 -->
    <div ref="reportsdiv" style="width: 1000px;height:800px;"></div>
  </div>
</template>

<script>
// 导入echarts
import echarts from "echarts";
// 导入接口
import { getReports } from "../api/http";

export default {
  name: "reports",
  // 获取dom元素最早在这里
  mounted() {
    // 基于准备好的dom，初始化echarts实例
    // console.log(this.$refs.reportsdiv)
    // var myChart = echarts.init(this.$refs.reportsdiv);
    // // 使用刚指定的配置项和数据显示图表。
    // myChart.setOption(this.option);
    // getReports().then(backData => {
    //   // console.log(backData);
    //   // 和本地的集合
    //   for (const key in backData.data.data) {
    //     // 相同的数据赋值
    //     this.option[key] = backData.data.data[key];
    //     var myChart = echarts.init(this.$refs.reportsdiv);

    //     // // 使用刚指定的配置项和数据显示图表。
    //     myChart.setOption(this.option);
    //   }
    // });
  },
  created() {
    // 调用接口
    getReports().then(backData => {
      // console.log(backData);
      // 和本地的集合
      for (const key in backData.data.data) {
        // 相同的数据赋值
        this.option[key] = backData.data.data[key];
        // nextTick一定会在dom更新完毕之后执行 
        // 注册了一个回调函数，会在dom更新完毕之后触发
        this.$nextTick(()=>{
          var myChart = echarts.init(this.$refs.reportsdiv);
          // // 使用刚指定的配置项和数据显示图表。
          myChart.setOption(this.option);
        })
      }
    });
  },
  // 数据
  data() {
    return {
      // echarts的基础数据
      option: {
        title: {
          text: "用户来源"
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "cross",
            label: {
              backgroundColor: "#6a7985"
            }
          }
        },
        legend: {
          data: ["邮件营销", "联盟广告", "视频广告", "直接访问", "搜索引擎"]
        },
        toolbox: {
          feature: {
            saveAsImage: {}
          }
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        xAxis: [
          {
            type: "category",
            boundaryGap: false,
            data: ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
          }
        ],
        yAxis: [
          {
            type: "value"
          }
        ],
        series: [
          {
            name: "邮件营销",
            type: "line",
            stack: "总量",
            areaStyle: {},
            data: [120, 132, 101, 134, 90, 230, 210]
          },
          {
            name: "联盟广告",
            type: "line",
            stack: "总量",
            areaStyle: {},
            data: [220, 182, 191, 234, 290, 330, 310]
          },
          {
            name: "视频广告",
            type: "line",
            stack: "总量",
            areaStyle: {},
            data: [150, 232, 201, 154, 190, 330, 410]
          },
          {
            name: "直接访问",
            type: "line",
            stack: "总量",
            areaStyle: { normal: {} },
            data: [320, 332, 301, 334, 390, 330, 320]
          },
          {
            name: "搜索引擎",
            type: "line",
            stack: "总量",
            label: {
              normal: {
                show: true,
                position: "top"
              }
            },
            areaStyle: { normal: {} },
            data: [820, 932, 901, 934, 1290, 1330, 1320]
          }
        ]
      }
    };
  }
};
</script>

<style scoped lang="less">
</style>
